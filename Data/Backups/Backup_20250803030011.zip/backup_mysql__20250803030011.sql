-- MySqlBackup.NET 2.3.9.0
-- Dump Time: 2025-08-03 03:00:11
-- --------------------------------------
-- Server version 9.4.0 MySQL Community Server - GPL


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of __EFMigrationsHistory
-- 

DROP TABLE IF EXISTS `__EFMigrationsHistory`;
CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
  `MigrationId` varchar(150) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table __EFMigrationsHistory
-- 

/*!40000 ALTER TABLE `__EFMigrationsHistory` DISABLE KEYS */;
INSERT INTO `__EFMigrationsHistory`(`MigrationId`,`ProductVersion`) VALUES('20250327193326_MigrateToMySQL','8.0.11'),('20250330181953_AddUserGrades','8.0.11'),('20250403173344_AddCustomBeatmapStatuses','8.0.11'),('20250426214100_OptimizeIndexesUsages','8.0.11'),('20250427104756_AddDbIndexForFilterValidScores','8.0.11'),('20250506223339_AddDefaultGamemodeToUser','8.0.11'),('20250508213243_AddUserMetadataTable','8.0.11'),('20250509040239_AddUserRelationshipTable','8.0.11'),('20250509040446_MigrateUsersFriendsToRelationshipTable','8.0.11'),('20250509042335_RemoveOldUserStringFieldInUser','8.0.11'),('20250510012606_RevertRemovingNullableFromUserStatsBestValues','8.0.11'),('20250510012726_FixAllBadBestValuesForUserStats','8.0.11'),('20250512014617_AddUserInventoryItemAndBeatmapHypes','8.0.11'),('20250512014640_AddDefaultWeeklyUserHypesInTheirInventory','8.0.11'),('20250519134402_UseWebBeatmapStatusForCustomStatuses','8.0.11'),('20250520134458_AddBeatmapEvents','8.0.11'),('20250602141333_ClearUserStatsDuplicates','8.0.11'),('20250602141359_MakeUserStatsIndexUnique','8.0.11');
/*!40000 ALTER TABLE `__EFMigrationsHistory` ENABLE KEYS */;

-- 
-- Definition of medal_file
-- 

DROP TABLE IF EXISTS `medal_file`;
CREATE TABLE IF NOT EXISTS `medal_file` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Path` longtext NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table medal_file
-- 

/*!40000 ALTER TABLE `medal_file` DISABLE KEYS */;
INSERT INTO `medal_file`(`Id`,`Path`,`CreatedAt`) VALUES(1,'Files/Medals/all-secret-thisdjisfire.png','2025-08-01 10:02:45.148124'),(2,'Files/Medals/all-secret-heat-abnormal.png','2025-08-01 10:02:45.278570');
/*!40000 ALTER TABLE `medal_file` ENABLE KEYS */;

-- 
-- Definition of medal
-- 

DROP TABLE IF EXISTS `medal`;
CREATE TABLE IF NOT EXISTS `medal` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` longtext NOT NULL,
  `Description` longtext NOT NULL,
  `GameMode` tinyint unsigned DEFAULT NULL,
  `Category` int NOT NULL,
  `FileUrl` longtext,
  `FileId` int DEFAULT NULL,
  `Condition` longtext NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_medal_Category` (`Category`),
  KEY `IX_medal_FileId` (`FileId`),
  KEY `IX_medal_GameMode` (`GameMode`),
  CONSTRAINT `FK_medal_medal_file_FileId` FOREIGN KEY (`FileId`) REFERENCES `medal_file` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table medal
-- 

/*!40000 ALTER TABLE `medal` DISABLE KEYS */;
INSERT INTO `medal`(`Id`,`Name`,`Description`,`GameMode`,`Category`,`FileUrl`,`FileId`,`Condition`) VALUES(1,'Rising Star','Can''t go forward without the first steps.',0,4,'osu-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(2,'Constellation Prize','Definitely not a consolation prize. Now things start getting hard!',0,4,'osu-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(3,'Building Confidence','Oh, you''ve SO got this.',0,4,'osu-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(4,'Insanity Approaches','You''re not twitching, you''re just ready.',0,4,'osu-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(5,'These Clarion Skies','Everything seems so clear now.',0,4,'osu-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(6,'Above and Beyond','A cut above the rest.',0,4,'osu-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(7,'Supremacy','All marvel before your prowess.',0,4,'osu-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(8,'Absolution','My god, you''re full of stars!',0,4,'osu-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(9,'Event Horizon','No force dares to pull you under.',0,4,'osu-skill-pass-9',NULL,'beatmap.DifficultyRating >= 9 && beatmap.DifficultyRating < 10'),(10,'Phantasm','Fevered is your passion, extraordinary is your skill.',0,4,'osu-skill-pass-10',NULL,'beatmap.DifficultyRating >= 10 && beatmap.DifficultyRating < 11'),(11,'Totality','All the notes. Every single one.',0,4,'osu-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(12,'Business As Usual','Two to go, please.',0,4,'osu-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(13,'Building Steam','Hey, this isn''t so bad.',0,4,'osu-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(14,'Moving Forward','Bet you feel good about that.',0,4,'osu-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(15,'Paradigm Shift','Surprisingly difficult.',0,4,'osu-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(16,'Anguish Quelled','Don''t choke.',0,4,'osu-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(17,'Never Give Up','Excellence is its own reward.',0,4,'osu-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(18,'Aberration','They said it couldn''t be done. They were wrong.',0,4,'osu-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(19,'Chosen','Reign among the Prometheans, where you belong.',0,4,'osu-skill-fc-9',NULL,'beatmap.DifficultyRating >= 9 && beatmap.DifficultyRating < 10 && score.Perfect'),(20,'Unfathomable','You have no equal.',0,4,'osu-skill-fc-10',NULL,'beatmap.DifficultyRating >= 10 && beatmap.DifficultyRating < 11 && score.Perfect'),(21,'500 Combo','500 big ones! You''re moving up in the world!',0,4,'osu-combo-500',NULL,'score.MaxCombo >= 500'),(22,'750 Combo','750 notes back to back? Woah.',0,4,'osu-combo-750',NULL,'score.MaxCombo >= 750'),(23,'1,000 Combo','A thousand reasons why you rock at this game.',0,4,'osu-combo-1000',NULL,'score.MaxCombo >= 1000'),(24,'2,000 Combo','Nothing can stop you now.',0,4,'osu-combo-2000',NULL,'score.MaxCombo >= 2000'),(25,'5,000 Plays','There''s a lot more where that came from.',0,4,'osu-plays-5000',NULL,'user.PlayCount >= 5000'),(26,'15,000 Plays','Must.. click.. circles..',0,4,'osu-plays-15000',NULL,'user.PlayCount >= 15000'),(27,'25,000 Plays','There''s no going back.',0,4,'osu-plays-25000',NULL,'user.PlayCount >= 25000'),(28,'50,000 Plays','You''re here forever.',0,4,'osu-plays-50000',NULL,'user.PlayCount >= 50000'),(29,'My First Don','Marching to the beat of your own drum. Literally.',1,4,'taiko-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(30,'Katsu Katsu Katsu','Hora! Ikuzo!',1,4,'taiko-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(31,'Not Even Trying','Muzukashii? Not even.',1,4,'taiko-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(32,'Face Your Demons','The first trials are now behind you, but are you a match for the Oni?',1,4,'taiko-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(33,'The Demon Within','No rest for the wicked.',1,4,'taiko-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(34,'Drumbreaker','Too strong.',1,4,'taiko-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(35,'The Godfather','You are the Don of Dons.',1,4,'taiko-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(36,'Rhythm Incarnate','Feel the beat. Become the beat.',1,4,'taiko-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(37,'Keeping Time','Don, then katsu. Don, then katsu..',1,4,'taiko-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(38,'To Your Own Beat','Straight and steady.',1,4,'taiko-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(39,'Big Drums','Bigger scores to match.',1,4,'taiko-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(40,'Adversity Overcome','Difficult? Not for you.',1,4,'taiko-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(41,'Demonslayer','An Oni felled forevermore.',1,4,'taiko-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(42,'''Rhythm''s Call','Heralding true skill.',1,4,'taiko-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(43,'Time Everlasting','Not a single beat escapes you.',1,4,'taiko-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(44,'The Drummer''s Throne','Percussive brilliance befitting royalty alone.',1,4,'taiko-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(45,'30,000 Drum Hits','Did that drum have a face?',1,4,'taiko-hits-30000',NULL,'user.TotalHits >= 30000'),(46,'300,000 Drum Hits','The rhythm never stops.',1,4,'taiko-hits-300000',NULL,'user.TotalHits >= 300000'),(47,'3,000,000 Drum Hits','Truly, the Don of dons.',1,4,'taiko-hits-3000000',NULL,'user.TotalHits >= 3000000'),(48,'30,000,000 Drum Hits','Your rhythm, eternal.',1,4,'taiko-hits-30000000',NULL,'user.TotalHits >= 30000000'),(49,'A Slice Of Life','Hey, this fruit catching business isn''t bad.',2,4,'fruits-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(50,'Dashing Ever Forward','Fast is how you do it.',2,4,'fruits-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(51,'Zesty Disposition','No scurvy for you, not with that much fruit.',2,4,'fruits-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(52,'Hyperdash ON!','Time and distance is no obstacle to you.',2,4,'fruits-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(53,'It''s Raining Fruit','And you can catch them all.',2,4,'fruits-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(54,'Fruit Ninja','Legendary techniques.',2,4,'fruits-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(55,'Dreamcatcher','No fruit, only dreams now.',2,4,'fruits-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(56,'Lord of the Catch','Your kingdom kneels before you.',2,4,'fruits-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(57,'Sweet And Sour','Apples and oranges, literally.',2,4,'fruits-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(58,'Reaching The Core','The seeds of future success.',2,4,'fruits-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(59,'Clean Platter','Clean only of failure. It is completely full, otherwise.',2,4,'fruits-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(60,'Between The Rain','No umbrella needed.',2,4,'fruits-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(61,'Addicted','That was an overdose?',2,4,'fruits-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(62,'Quickening','A dash above normal limits.',2,4,'fruits-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(63,'Supersonic','Faster than is reasonably necessary.',2,4,'fruits-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(64,'Dashing Scarlet','Speed beyond mortal reckoning.',2,4,'fruits-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(65,'Catch 20,000 fruits','That is a lot of dietary fiber.',2,4,'fruits-hits-20000',NULL,'user.TotalHits >= 20000'),(66,'Catch 200,000 fruits','So, I heard you like fruit...',2,4,'fruits-hits-200000',NULL,'user.TotalHits >= 200000'),(67,'Catch 2,000,000 fruits','Downright healthy.',2,4,'fruits-hits-2000000',NULL,'user.TotalHits >= 2000000'),(68,'Catch 20,000,000 fruits','Nothing left behind.',2,4,'fruits-hits-20000000',NULL,'user.TotalHits >= 20000000'),(69,'First Steps','It isn''t 9-to-4, but 1-to-9. Keys, that is.',3,4,'mania-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(70,'No Normal Player','Not anymore, at least.',3,4,'mania-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(71,'Impulse Drive','Not quite hyperspeed, but getting close.',3,4,'mania-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(72,'Hyperspeed','Woah.',3,4,'mania-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(73,'Ever Onwards','Another challenge is just around the corner.',3,4,'mania-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(74,'Another Surpassed','Is there no limit to your skills?',3,4,'mania-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(75,'Extra Credit','See me after class.',3,4,'mania-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(76,'Maniac','There''s just no stopping you.',3,4,'mania-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(77,'Keystruck','The beginning of a new story.',3,4,'mania-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(78,'Keying In','Finding your groove.',3,4,'mania-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(79,'Hyperflow','You can *feel* the rhythm.',3,4,'mania-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(80,'Breakthrough','Many skills mastered, rolled into one.',3,4,'mania-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(81,'Everything Extra','Giving your all is giving everything you have.',3,4,'mania-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(82,'Level Breaker','Finesse beyond reason.',3,4,'mania-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(83,'Step Up','A precipice rarely seen.',3,4,'mania-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(84,'Behind The Veil','Supernatural!',3,4,'mania-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(85,'40,000 Keys','Just the start of the rainbow.',3,4,'mania-hits-40000',NULL,'user.TotalHits >= 40000'),(86,'400,000 Keys','Four hundred thousand and still not even close.',3,4,'mania-hits-400000',NULL,'user.TotalHits >= 400000'),(87,'4,000,000 Keys','Is this the end of the rainbow?',3,4,'mania-hits-4000000',NULL,'user.TotalHits >= 4000000'),(88,'40,000,000 Keys','The rainbow is eternal.',3,4,'mania-hits-40000000',NULL,'user.TotalHits >= 40000000'),(89,'Finality','High stakes, no regrets.',NULL,3,'all-intro-suddendeath',NULL,'(score.Mods & 32) == 32'),(90,'Perfectionist','Accept nothing but the best.',NULL,3,'all-intro-perfect',NULL,'(score.Mods & 16384) == 16384'),(91,'Rock Around The Clock','You can''t stop the rock.',NULL,3,'all-intro-hardrock',NULL,'(score.Mods & 16) == 16'),(92,'Time And A Half','Having a right ol'' time. One and a half of them, almost.',NULL,3,'all-intro-doubletime',NULL,'(score.Mods & 64) == 64'),(93,'Sweet Rave Party','Founded in the fine tradition of changing things that were just fine as they were.',NULL,3,'all-intro-nightcore',NULL,'(score.Mods & 512) == 512'),(94,'Blindsight','I can see just perfectly.',NULL,3,'all-intro-hidden',NULL,'(score.Mods & 8) == 8'),(95,'Are You Afraid Of The Dark?','Harder than it looks, probably because it''s hard to look.',NULL,3,'all-intro-flashlight',NULL,'(score.Mods & 1024) == 1024'),(96,'Dial It Right Back','Sometimes you just want to take it easy.',NULL,3,'all-intro-easy',NULL,'(score.Mods & 2) == 2'),(97,'Risk Averse','Safety nets are fun!',NULL,3,'all-intro-nofail',NULL,'(score.Mods & 1) == 1'),(98,'Slowboat','You got there. Eventually.',NULL,3,'all-intro-halftime',NULL,'(score.Mods & 256) == 256'),(99,'Burned Out','One cannot always spin to win.',NULL,3,'all-intro-spunout',NULL,'(score.Mods & 4096) == 4096'),(100,'Man this DJ is fire','Just don''t listen to the original. It''s not as good.',NULL,2,NULL,1,'beatmap.BeatmapsetId == 1357624'),(101,'Heat abnormal','Is it just me, or does my head get dizzy from all the heat?',NULL,2,NULL,2,'beatmap.BeatmapsetId == 2058976');
/*!40000 ALTER TABLE `medal` ENABLE KEYS */;

-- 
-- Definition of user
-- 

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Passhash` longtext NOT NULL,
  `Description` longtext,
  `Country` smallint NOT NULL,
  `Privilege` int NOT NULL,
  `RegisterDate` datetime(6) NOT NULL,
  `LastOnlineTime` datetime(6) NOT NULL,
  `AccountStatus` int NOT NULL,
  `SilencedUntil` datetime(6) NOT NULL,
  `DefaultGameMode` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_Email` (`Email`),
  UNIQUE KEY `IX_user_Username` (`Username`),
  KEY `IX_user_AccountStatus` (`AccountStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user
-- 

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user`(`Id`,`Username`,`Email`,`Passhash`,`Description`,`Country`,`Privilege`,`RegisterDate`,`LastOnlineTime`,`AccountStatus`,`SilencedUntil`,`DefaultGameMode`) VALUES(1001,'Tosume Bot','bot@mail.com','12345678','Let your smile be the sunshine that brightens the world around you.',12,32,'2025-08-01 10:02:45.365194','2025-08-03 02:00:09.018405',0,'0001-01-01 00:00:00.000000',0),(1002,'Yazid','dahlahg7@gmail.com','c848b5b86a1cde2e42aadc543472f5a4',NULL,100,27,'2025-08-01 16:29:58.578012','2025-08-02 16:43:14.663340',0,'0001-01-01 00:00:00.000000',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- 
-- Definition of beatmap_hype
-- 

DROP TABLE IF EXISTS `beatmap_hype`;
CREATE TABLE IF NOT EXISTS `beatmap_hype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `UserId` int NOT NULL,
  `Hypes` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_beatmap_hype_BeatmapSetId_UserId` (`BeatmapSetId`,`UserId`),
  KEY `IX_beatmap_hype_BeatmapSetId_Hypes` (`BeatmapSetId`,`Hypes`),
  KEY `IX_beatmap_hype_UserId` (`UserId`),
  CONSTRAINT `FK_beatmap_hype_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table beatmap_hype
-- 

/*!40000 ALTER TABLE `beatmap_hype` DISABLE KEYS */;

/*!40000 ALTER TABLE `beatmap_hype` ENABLE KEYS */;

-- 
-- Definition of custom_beatmap_status
-- 

DROP TABLE IF EXISTS `custom_beatmap_status`;
CREATE TABLE IF NOT EXISTS `custom_beatmap_status` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `BeatmapHash` varchar(255) NOT NULL,
  `UpdatedByUserId` int NOT NULL,
  `Status` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_custom_beatmap_status_UpdatedByUserId` (`UpdatedByUserId`),
  KEY `IX_custom_beatmap_status_BeatmapHash` (`BeatmapHash`),
  KEY `IX_custom_beatmap_status_BeatmapSetId` (`BeatmapSetId`),
  CONSTRAINT `FK_custom_beatmap_status_user_UpdatedByUserId` FOREIGN KEY (`UpdatedByUserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table custom_beatmap_status
-- 

/*!40000 ALTER TABLE `custom_beatmap_status` DISABLE KEYS */;
INSERT INTO `custom_beatmap_status`(`Id`,`BeatmapSetId`,`BeatmapHash`,`UpdatedByUserId`,`Status`) VALUES(1,1495669,'c81416494395b5e2e937d6fee8af96da',1002,1),(2,1495669,'4b6aa6be69bc82abdf9dda3342c1bd6a',1002,1),(3,1495669,'fcedd86c76d017ee961a7c226f311076',1002,1),(4,1495669,'97c09979f3190bda6b8739ec9499a25c',1002,1),(5,1495669,'c438b797937c795c407cba85ffaebb66',1002,1),(6,1495669,'241630cbe3c8b10aaf2e79b6ea4d886f',1002,1),(7,1495669,'946ef9db41b2ac8b049e6e55beee626b',1002,1),(8,1495669,'d8027c186b3741941263ed6bd78549f7',1002,1),(9,1495669,'c4f56829943943529c9f75b3fd0edc84',1002,1),(10,1495669,'8c50d4c22a395d3514a98f22f0b91a0c',1002,1),(11,1495669,'6a2b011f314c9369553f6b8d5723d385',1002,1),(12,1495669,'1650634f780a394bdd037ebc3ab2e24f',1002,1),(13,1495669,'d997a6bb8d0ae7a8a4c82d34a3bc22b8',1002,1),(14,1495669,'6cf44cc4b201e019ed91a22fe1ef163c',1002,1),(15,1495669,'5d2b440af417047c22ab5b7bdd48e359',1002,1),(16,1495669,'c5acdfa67215856957d596b72317b11f',1002,1),(17,1495669,'06d2e5e4df3554b8ec342f7596643891',1002,1),(18,1495669,'2ad5614f4c535b1b267b581ee04bc816',1002,1),(19,1495669,'65c0eb0c9e36d4807ae9828f510dd6e0',1002,1),(20,1495669,'4b5b848b0bb88639632e742e80c3c01b',1002,1),(21,1495669,'cf59867d52ab287ca55c6425568424e9',1002,1),(22,1495669,'42754fa87279c5611a850e1f50ef8d95',1002,1),(23,1495669,'c7baaa54fd1c20e9a666b2e865b476a4',1002,1),(24,1495669,'b595485ce18e908164574389bb291f57',1002,1),(25,1495669,'8ae65fba53a9387ba267ec59a6310618',1002,1),(26,1495669,'4ed7e341fff2d46d61f0079e0b877bb9',1002,1),(27,1495669,'6f3b0f23adaabc418d3487f40fdd17de',1002,1),(28,1495669,'d1d053fd415715f147ddba4756a28b1d',1002,1),(29,1495669,'491a85c0f9f3d4249390755cc17490a7',1002,1),(30,1495669,'cc239d137ddd1211f845a8fe25898376',1002,1),(31,1495669,'6e959f98a7b25bfb111683bfedbab2db',1002,1),(32,1495669,'9db323ed5856c610be2420f14da08872',1002,1),(33,1495669,'56f29d5523b000f490394e68b410ca02',1002,1),(34,1495669,'e4a2fa6ad06f7a29a23c856f329584fe',1002,1),(35,1495669,'eca8193bb48c3756a4cd4dba6f96e8bc',1002,1),(36,1495669,'0d6b925128864a217a0a206e227babd0',1002,1),(37,1495669,'0477f5e6e471367413cbf4f605f11a9a',1002,1),(38,1495669,'f30ba8c57e259a39ed9e169c6cc5a713',1002,1),(39,1495669,'0bd9163245f140056e376039c7b5fec4',1002,1),(40,1495669,'6a8c6ab6061fbf6d07289cf20f540a0c',1002,1),(41,1495669,'7e1d6c7556ce32d19c7dc17e15ee14aa',1002,1),(42,1495669,'4cf1c6e855abf5fd7cc804e68a6e21e9',1002,1),(43,1495669,'025278e4a590bc6a3f2832a19d637a72',1002,1),(44,1495669,'b7cf44257d19b0336baf25dd7db0dd0f',1002,1),(45,1495669,'9748f8aada8015ee66670da729785033',1002,1),(46,1495669,'c027249486ac372127f8f641a4dad49c',1002,1),(47,1495669,'1be603d488aa9eee0ee4d8c3b84f1b3c',1002,1),(48,1495669,'8dc3bf9a4b969d5c209fa6b48833329f',1002,1),(49,1495669,'fd5f37ec89ef9ebb2896d41cd632abca',1002,1),(50,1495669,'30d675bfed2611481e6385916618abe8',1002,1),(51,1495669,'3fc009abaf2428ddddde5d49de448eff',1002,1),(52,1495669,'04437951e6b8be07d833f805b77a6469',1002,1),(53,1495669,'b15b9b433b8e4635717b3774f6eb5c5b',1002,1),(54,1495669,'adb3e0c8d944e1ec90002ee1d5698dde',1002,1),(55,1495669,'1874d32cc7cbe5cbfd7645e39ddca5ee',1002,1),(56,1495669,'4ee727d5e7cb2bfdd4ed72c0b00c5f76',1002,1),(57,1495669,'857fcbdc49e174318fab2c5d7d59d19d',1002,1),(58,1495669,'297c1c61265388de9dbbcaa0d433c3f2',1002,1),(59,1495669,'c68d56155c97fccdd773a8fd265954a6',1002,1),(60,1495669,'13906d5893ef6eb51717115519664cb6',1002,1),(61,1495669,'4f241bc3b88503d3ea1ed10f84f4c081',1002,1),(62,1495669,'879ed616cdabc79cda22fd562a590087',1002,1),(63,1495669,'a8e080740ef890cc077abbafb0e6f98f',1002,1),(64,1495669,'72fe21f3f93a7af9a83c3643c2d0924d',1002,1),(65,1495669,'3131a43098a2a384ee15e0f95d655441',1002,1),(66,1495669,'c878f07a664e7221658c12968b4b1716',1002,1),(67,1495669,'7be49d835047bf5835faea02e8c1d4ef',1002,1),(68,1495669,'63a4cba7977e3ad7954e2753a2e9c1f7',1002,1),(69,1495669,'766d77e5a12ff11cc31d8b6b6b664652',1002,1),(70,1495669,'bedb8a89475c9305a7c85918c78c0f44',1002,1),(71,1495669,'e3d5591633ce6841465c4bb0add2c229',1002,1),(72,1495669,'380dd9139e5dd6babdb22882b11aa9d7',1002,1),(73,1495669,'ef604f6e63a75daf7acd9d187b5f80b2',1002,1),(74,1495669,'ee7cf3c589c300c3249ccd9191911042',1002,1),(75,1495669,'cd37dd09bf1a589b3a74db8dc926997f',1002,1),(76,1495669,'a4669cb7af47a4ae609c4df5385ef499',1002,1),(77,1495669,'5992a59b0f31b46077a16af58f61f620',1002,1),(78,1495669,'bb061ed3b8d0ad58fe1f3f007ca6bb66',1002,1),(79,1495669,'8ede397a364cf9c714fa240ba20c117a',1002,1),(80,1495669,'8985416218cb971a4e4bc253eee8a84b',1002,1),(81,1495669,'e0897142aae578d58e6bbad080946a94',1002,1),(82,1495669,'3a40d949cde64288374c73357b31c56e',1002,1),(83,1495669,'165d5bea9120127aa5a50c4ebc2dc1fd',1002,1),(84,1495669,'10be9585678536d576a5724fcac51ac9',1002,1),(85,1495669,'af54ccfd71986d7f0bed82d2e56e5771',1002,1),(86,1495669,'d52de7f10f5b13a3fac0bb3d855b204d',1002,1),(87,1495669,'8fe2a6927935540a45b6601205edaa3b',1002,1),(88,1495669,'e6d21293822c06192b9d25fc00e4d675',1002,1),(89,1495669,'8aa01ff2368c9b29f8efce00784c6e54',1002,1),(90,1495669,'1501422bf5735d9ae1bf0e3ebd423d45',1002,1),(91,1495669,'7b3dba790972352adbc7ee1725fabc4c',1002,1),(92,1495669,'40e32b3151ccf610b9b7ea912d4e800c',1002,1),(93,1495669,'2dc0c7925ed47b0c10c914a37755a1d2',1002,1),(94,1495669,'22aaf291b56cdfa40c395134c8b259f4',1002,1),(95,1495669,'0bd3d00f007c4efedab33bee351dcc42',1002,1),(96,1495669,'789fbb2cfce7a5d30aad22225e823763',1002,1),(97,1495669,'d94985866ebc25545e01c98168740181',1002,1),(98,1495669,'d125bfd62ee091de671cbe5f3b85f1eb',1002,1),(99,1495669,'3ea5987d7f16795fc80566dfd04829b1',1002,1),(100,1495669,'07861aaeb531b52f365da2600d35b9a1',1002,1),(101,1495669,'0990703787ff70c9cafc1bb3c9b2c473',1002,1),(102,1495669,'42e49348d83bbd4fd7956d3bf1cc9084',1002,1),(103,1495669,'70902f82de6fdf9eeedf1a76db8ad8ea',1002,1),(104,1495669,'281a6f1b29c9bfd68625c8d9e12a030d',1002,1);
/*!40000 ALTER TABLE `custom_beatmap_status` ENABLE KEYS */;

-- 
-- Definition of event_beatmap
-- 

DROP TABLE IF EXISTS `event_beatmap`;
CREATE TABLE IF NOT EXISTS `event_beatmap` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `ExecutorId` int NOT NULL,
  `EventType` int NOT NULL,
  `JsonData` longtext,
  `Time` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_event_beatmap_BeatmapSetId` (`BeatmapSetId`),
  KEY `IX_event_beatmap_ExecutorId` (`ExecutorId`),
  CONSTRAINT `FK_event_beatmap_user_ExecutorId` FOREIGN KEY (`ExecutorId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table event_beatmap
-- 

/*!40000 ALTER TABLE `event_beatmap` DISABLE KEYS */;
INSERT INTO `event_beatmap`(`Id`,`BeatmapSetId`,`ExecutorId`,`EventType`,`JsonData`,`Time`) VALUES(1,1495669,1002,1,'{\"beatmap_hash\":\"c81416494395b5e2e937d6fee8af96da\",\"new_status\":1}','2025-08-02 09:26:39.579808'),(2,1495669,1002,1,'{\"beatmap_hash\":\"4b6aa6be69bc82abdf9dda3342c1bd6a\",\"new_status\":1}','2025-08-02 09:26:39.627940'),(3,1495669,1002,1,'{\"beatmap_hash\":\"fcedd86c76d017ee961a7c226f311076\",\"new_status\":1}','2025-08-02 09:26:39.649357'),(4,1495669,1002,1,'{\"beatmap_hash\":\"97c09979f3190bda6b8739ec9499a25c\",\"new_status\":1}','2025-08-02 09:26:39.671506'),(5,1495669,1002,1,'{\"beatmap_hash\":\"c438b797937c795c407cba85ffaebb66\",\"new_status\":1}','2025-08-02 09:26:39.701914'),(6,1495669,1002,1,'{\"beatmap_hash\":\"241630cbe3c8b10aaf2e79b6ea4d886f\",\"new_status\":1}','2025-08-02 09:26:39.722104'),(7,1495669,1002,1,'{\"beatmap_hash\":\"946ef9db41b2ac8b049e6e55beee626b\",\"new_status\":1}','2025-08-02 09:26:39.739697'),(8,1495669,1002,1,'{\"beatmap_hash\":\"d8027c186b3741941263ed6bd78549f7\",\"new_status\":1}','2025-08-02 09:26:39.756185'),(9,1495669,1002,1,'{\"beatmap_hash\":\"c4f56829943943529c9f75b3fd0edc84\",\"new_status\":1}','2025-08-02 09:26:39.774010'),(10,1495669,1002,1,'{\"beatmap_hash\":\"8c50d4c22a395d3514a98f22f0b91a0c\",\"new_status\":1}','2025-08-02 09:26:39.792724'),(11,1495669,1002,1,'{\"beatmap_hash\":\"6a2b011f314c9369553f6b8d5723d385\",\"new_status\":1}','2025-08-02 09:26:39.811870'),(12,1495669,1002,1,'{\"beatmap_hash\":\"1650634f780a394bdd037ebc3ab2e24f\",\"new_status\":1}','2025-08-02 09:26:39.831384'),(13,1495669,1002,1,'{\"beatmap_hash\":\"d997a6bb8d0ae7a8a4c82d34a3bc22b8\",\"new_status\":1}','2025-08-02 09:26:39.851487'),(14,1495669,1002,1,'{\"beatmap_hash\":\"6cf44cc4b201e019ed91a22fe1ef163c\",\"new_status\":1}','2025-08-02 09:26:39.871131'),(15,1495669,1002,1,'{\"beatmap_hash\":\"5d2b440af417047c22ab5b7bdd48e359\",\"new_status\":1}','2025-08-02 09:26:39.907677'),(16,1495669,1002,1,'{\"beatmap_hash\":\"c5acdfa67215856957d596b72317b11f\",\"new_status\":1}','2025-08-02 09:26:39.937481'),(17,1495669,1002,1,'{\"beatmap_hash\":\"06d2e5e4df3554b8ec342f7596643891\",\"new_status\":1}','2025-08-02 09:26:39.964516'),(18,1495669,1002,1,'{\"beatmap_hash\":\"2ad5614f4c535b1b267b581ee04bc816\",\"new_status\":1}','2025-08-02 09:26:39.983341'),(19,1495669,1002,1,'{\"beatmap_hash\":\"65c0eb0c9e36d4807ae9828f510dd6e0\",\"new_status\":1}','2025-08-02 09:26:40.001170'),(20,1495669,1002,1,'{\"beatmap_hash\":\"4b5b848b0bb88639632e742e80c3c01b\",\"new_status\":1}','2025-08-02 09:26:40.019897'),(21,1495669,1002,1,'{\"beatmap_hash\":\"cf59867d52ab287ca55c6425568424e9\",\"new_status\":1}','2025-08-02 09:26:40.037786'),(22,1495669,1002,1,'{\"beatmap_hash\":\"42754fa87279c5611a850e1f50ef8d95\",\"new_status\":1}','2025-08-02 09:26:40.055994'),(23,1495669,1002,1,'{\"beatmap_hash\":\"c7baaa54fd1c20e9a666b2e865b476a4\",\"new_status\":1}','2025-08-02 09:26:40.073083'),(24,1495669,1002,1,'{\"beatmap_hash\":\"b595485ce18e908164574389bb291f57\",\"new_status\":1}','2025-08-02 09:26:40.093092'),(25,1495669,1002,1,'{\"beatmap_hash\":\"8ae65fba53a9387ba267ec59a6310618\",\"new_status\":1}','2025-08-02 09:26:40.120354'),(26,1495669,1002,1,'{\"beatmap_hash\":\"4ed7e341fff2d46d61f0079e0b877bb9\",\"new_status\":1}','2025-08-02 09:26:40.140133'),(27,1495669,1002,1,'{\"beatmap_hash\":\"6f3b0f23adaabc418d3487f40fdd17de\",\"new_status\":1}','2025-08-02 09:26:40.158808'),(28,1495669,1002,1,'{\"beatmap_hash\":\"d1d053fd415715f147ddba4756a28b1d\",\"new_status\":1}','2025-08-02 09:26:40.176962'),(29,1495669,1002,1,'{\"beatmap_hash\":\"491a85c0f9f3d4249390755cc17490a7\",\"new_status\":1}','2025-08-02 09:26:40.195243'),(30,1495669,1002,1,'{\"beatmap_hash\":\"cc239d137ddd1211f845a8fe25898376\",\"new_status\":1}','2025-08-02 09:26:40.216703'),(31,1495669,1002,1,'{\"beatmap_hash\":\"6e959f98a7b25bfb111683bfedbab2db\",\"new_status\":1}','2025-08-02 09:26:40.237065'),(32,1495669,1002,1,'{\"beatmap_hash\":\"9db323ed5856c610be2420f14da08872\",\"new_status\":1}','2025-08-02 09:26:40.259108'),(33,1495669,1002,1,'{\"beatmap_hash\":\"56f29d5523b000f490394e68b410ca02\",\"new_status\":1}','2025-08-02 09:26:40.280447'),(34,1495669,1002,1,'{\"beatmap_hash\":\"e4a2fa6ad06f7a29a23c856f329584fe\",\"new_status\":1}','2025-08-02 09:26:40.315382'),(35,1495669,1002,1,'{\"beatmap_hash\":\"eca8193bb48c3756a4cd4dba6f96e8bc\",\"new_status\":1}','2025-08-02 09:26:40.333880'),(36,1495669,1002,1,'{\"beatmap_hash\":\"0d6b925128864a217a0a206e227babd0\",\"new_status\":1}','2025-08-02 09:26:40.355444'),(37,1495669,1002,1,'{\"beatmap_hash\":\"0477f5e6e471367413cbf4f605f11a9a\",\"new_status\":1}','2025-08-02 09:26:40.374503'),(38,1495669,1002,1,'{\"beatmap_hash\":\"f30ba8c57e259a39ed9e169c6cc5a713\",\"new_status\":1}','2025-08-02 09:26:40.393030'),(39,1495669,1002,1,'{\"beatmap_hash\":\"0bd9163245f140056e376039c7b5fec4\",\"new_status\":1}','2025-08-02 09:26:40.417525'),(40,1495669,1002,1,'{\"beatmap_hash\":\"6a8c6ab6061fbf6d07289cf20f540a0c\",\"new_status\":1}','2025-08-02 09:26:40.436474'),(41,1495669,1002,1,'{\"beatmap_hash\":\"7e1d6c7556ce32d19c7dc17e15ee14aa\",\"new_status\":1}','2025-08-02 09:26:40.455023'),(42,1495669,1002,1,'{\"beatmap_hash\":\"4cf1c6e855abf5fd7cc804e68a6e21e9\",\"new_status\":1}','2025-08-02 09:26:40.471590'),(43,1495669,1002,1,'{\"beatmap_hash\":\"025278e4a590bc6a3f2832a19d637a72\",\"new_status\":1}','2025-08-02 09:26:40.508997'),(44,1495669,1002,1,'{\"beatmap_hash\":\"b7cf44257d19b0336baf25dd7db0dd0f\",\"new_status\":1}','2025-08-02 09:26:40.530449'),(45,1495669,1002,1,'{\"beatmap_hash\":\"9748f8aada8015ee66670da729785033\",\"new_status\":1}','2025-08-02 09:26:40.549553'),(46,1495669,1002,1,'{\"beatmap_hash\":\"c027249486ac372127f8f641a4dad49c\",\"new_status\":1}','2025-08-02 09:26:40.567934'),(47,1495669,1002,1,'{\"beatmap_hash\":\"1be603d488aa9eee0ee4d8c3b84f1b3c\",\"new_status\":1}','2025-08-02 09:26:40.587971'),(48,1495669,1002,1,'{\"beatmap_hash\":\"8dc3bf9a4b969d5c209fa6b48833329f\",\"new_status\":1}','2025-08-02 09:26:40.609857'),(49,1495669,1002,1,'{\"beatmap_hash\":\"fd5f37ec89ef9ebb2896d41cd632abca\",\"new_status\":1}','2025-08-02 09:26:40.631533'),(50,1495669,1002,1,'{\"beatmap_hash\":\"30d675bfed2611481e6385916618abe8\",\"new_status\":1}','2025-08-02 09:26:40.650007'),(51,1495669,1002,1,'{\"beatmap_hash\":\"3fc009abaf2428ddddde5d49de448eff\",\"new_status\":1}','2025-08-02 09:26:40.673170'),(52,1495669,1002,1,'{\"beatmap_hash\":\"04437951e6b8be07d833f805b77a6469\",\"new_status\":1}','2025-08-02 09:26:40.709890'),(53,1495669,1002,1,'{\"beatmap_hash\":\"b15b9b433b8e4635717b3774f6eb5c5b\",\"new_status\":1}','2025-08-02 09:26:40.729893'),(54,1495669,1002,1,'{\"beatmap_hash\":\"adb3e0c8d944e1ec90002ee1d5698dde\",\"new_status\":1}','2025-08-02 09:26:40.750853'),(55,1495669,1002,1,'{\"beatmap_hash\":\"1874d32cc7cbe5cbfd7645e39ddca5ee\",\"new_status\":1}','2025-08-02 09:26:40.771574'),(56,1495669,1002,1,'{\"beatmap_hash\":\"4ee727d5e7cb2bfdd4ed72c0b00c5f76\",\"new_status\":1}','2025-08-02 09:26:40.792259'),(57,1495669,1002,1,'{\"beatmap_hash\":\"857fcbdc49e174318fab2c5d7d59d19d\",\"new_status\":1}','2025-08-02 09:26:40.813059'),(58,1495669,1002,1,'{\"beatmap_hash\":\"297c1c61265388de9dbbcaa0d433c3f2\",\"new_status\":1}','2025-08-02 09:26:40.839746'),(59,1495669,1002,1,'{\"beatmap_hash\":\"c68d56155c97fccdd773a8fd265954a6\",\"new_status\":1}','2025-08-02 09:26:40.860206'),(60,1495669,1002,1,'{\"beatmap_hash\":\"13906d5893ef6eb51717115519664cb6\",\"new_status\":1}','2025-08-02 09:26:40.883466'),(61,1495669,1002,1,'{\"beatmap_hash\":\"4f241bc3b88503d3ea1ed10f84f4c081\",\"new_status\":1}','2025-08-02 09:26:40.912815'),(62,1495669,1002,1,'{\"beatmap_hash\":\"879ed616cdabc79cda22fd562a590087\",\"new_status\":1}','2025-08-02 09:26:40.934615'),(63,1495669,1002,1,'{\"beatmap_hash\":\"a8e080740ef890cc077abbafb0e6f98f\",\"new_status\":1}','2025-08-02 09:26:40.958535'),(64,1495669,1002,1,'{\"beatmap_hash\":\"72fe21f3f93a7af9a83c3643c2d0924d\",\"new_status\":1}','2025-08-02 09:26:40.980251'),(65,1495669,1002,1,'{\"beatmap_hash\":\"3131a43098a2a384ee15e0f95d655441\",\"new_status\":1}','2025-08-02 09:26:41.002508'),(66,1495669,1002,1,'{\"beatmap_hash\":\"c878f07a664e7221658c12968b4b1716\",\"new_status\":1}','2025-08-02 09:26:41.026705'),(67,1495669,1002,1,'{\"beatmap_hash\":\"7be49d835047bf5835faea02e8c1d4ef\",\"new_status\":1}','2025-08-02 09:26:41.048430'),(68,1495669,1002,1,'{\"beatmap_hash\":\"63a4cba7977e3ad7954e2753a2e9c1f7\",\"new_status\":1}','2025-08-02 09:26:41.068857'),(69,1495669,1002,1,'{\"beatmap_hash\":\"766d77e5a12ff11cc31d8b6b6b664652\",\"new_status\":1}','2025-08-02 09:26:41.088939'),(70,1495669,1002,1,'{\"beatmap_hash\":\"bedb8a89475c9305a7c85918c78c0f44\",\"new_status\":1}','2025-08-02 09:26:41.124059'),(71,1495669,1002,1,'{\"beatmap_hash\":\"e3d5591633ce6841465c4bb0add2c229\",\"new_status\":1}','2025-08-02 09:26:41.147440'),(72,1495669,1002,1,'{\"beatmap_hash\":\"380dd9139e5dd6babdb22882b11aa9d7\",\"new_status\":1}','2025-08-02 09:26:41.167803'),(73,1495669,1002,1,'{\"beatmap_hash\":\"ef604f6e63a75daf7acd9d187b5f80b2\",\"new_status\":1}','2025-08-02 09:26:41.189862'),(74,1495669,1002,1,'{\"beatmap_hash\":\"ee7cf3c589c300c3249ccd9191911042\",\"new_status\":1}','2025-08-02 09:26:41.212382'),(75,1495669,1002,1,'{\"beatmap_hash\":\"cd37dd09bf1a589b3a74db8dc926997f\",\"new_status\":1}','2025-08-02 09:26:41.236711'),(76,1495669,1002,1,'{\"beatmap_hash\":\"a4669cb7af47a4ae609c4df5385ef499\",\"new_status\":1}','2025-08-02 09:26:41.258060'),(77,1495669,1002,1,'{\"beatmap_hash\":\"5992a59b0f31b46077a16af58f61f620\",\"new_status\":1}','2025-08-02 09:26:41.280625'),(78,1495669,1002,1,'{\"beatmap_hash\":\"bb061ed3b8d0ad58fe1f3f007ca6bb66\",\"new_status\":1}','2025-08-02 09:26:41.315904'),(79,1495669,1002,1,'{\"beatmap_hash\":\"8ede397a364cf9c714fa240ba20c117a\",\"new_status\":1}','2025-08-02 09:26:41.340429'),(80,1495669,1002,1,'{\"beatmap_hash\":\"8985416218cb971a4e4bc253eee8a84b\",\"new_status\":1}','2025-08-02 09:26:41.361872'),(81,1495669,1002,1,'{\"beatmap_hash\":\"e0897142aae578d58e6bbad080946a94\",\"new_status\":1}','2025-08-02 09:26:41.383056'),(82,1495669,1002,1,'{\"beatmap_hash\":\"3a40d949cde64288374c73357b31c56e\",\"new_status\":1}','2025-08-02 09:26:41.404856'),(83,1495669,1002,1,'{\"beatmap_hash\":\"165d5bea9120127aa5a50c4ebc2dc1fd\",\"new_status\":1}','2025-08-02 09:26:41.425142'),(84,1495669,1002,1,'{\"beatmap_hash\":\"10be9585678536d576a5724fcac51ac9\",\"new_status\":1}','2025-08-02 09:26:41.447943'),(85,1495669,1002,1,'{\"beatmap_hash\":\"af54ccfd71986d7f0bed82d2e56e5771\",\"new_status\":1}','2025-08-02 09:26:41.470521'),(86,1495669,1002,1,'{\"beatmap_hash\":\"d52de7f10f5b13a3fac0bb3d855b204d\",\"new_status\":1}','2025-08-02 09:26:41.492672'),(87,1495669,1002,1,'{\"beatmap_hash\":\"8fe2a6927935540a45b6601205edaa3b\",\"new_status\":1}','2025-08-02 09:26:41.536780'),(88,1495669,1002,1,'{\"beatmap_hash\":\"e6d21293822c06192b9d25fc00e4d675\",\"new_status\":1}','2025-08-02 09:26:41.557398'),(89,1495669,1002,1,'{\"beatmap_hash\":\"8aa01ff2368c9b29f8efce00784c6e54\",\"new_status\":1}','2025-08-02 09:26:41.586762'),(90,1495669,1002,1,'{\"beatmap_hash\":\"1501422bf5735d9ae1bf0e3ebd423d45\",\"new_status\":1}','2025-08-02 09:26:41.609049'),(91,1495669,1002,1,'{\"beatmap_hash\":\"7b3dba790972352adbc7ee1725fabc4c\",\"new_status\":1}','2025-08-02 09:26:41.630534'),(92,1495669,1002,1,'{\"beatmap_hash\":\"40e32b3151ccf610b9b7ea912d4e800c\",\"new_status\":1}','2025-08-02 09:26:41.655043'),(93,1495669,1002,1,'{\"beatmap_hash\":\"2dc0c7925ed47b0c10c914a37755a1d2\",\"new_status\":1}','2025-08-02 09:26:41.676782'),(94,1495669,1002,1,'{\"beatmap_hash\":\"22aaf291b56cdfa40c395134c8b259f4\",\"new_status\":1}','2025-08-02 09:26:41.698842'),(95,1495669,1002,1,'{\"beatmap_hash\":\"0bd3d00f007c4efedab33bee351dcc42\",\"new_status\":1}','2025-08-02 09:26:41.722331'),(96,1495669,1002,1,'{\"beatmap_hash\":\"789fbb2cfce7a5d30aad22225e823763\",\"new_status\":1}','2025-08-02 09:26:41.759208'),(97,1495669,1002,1,'{\"beatmap_hash\":\"d94985866ebc25545e01c98168740181\",\"new_status\":1}','2025-08-02 09:26:41.780944'),(98,1495669,1002,1,'{\"beatmap_hash\":\"d125bfd62ee091de671cbe5f3b85f1eb\",\"new_status\":1}','2025-08-02 09:26:41.803040'),(99,1495669,1002,1,'{\"beatmap_hash\":\"3ea5987d7f16795fc80566dfd04829b1\",\"new_status\":1}','2025-08-02 09:26:41.828313'),(100,1495669,1002,1,'{\"beatmap_hash\":\"07861aaeb531b52f365da2600d35b9a1\",\"new_status\":1}','2025-08-02 09:26:41.850001'),(101,1495669,1002,1,'{\"beatmap_hash\":\"0990703787ff70c9cafc1bb3c9b2c473\",\"new_status\":1}','2025-08-02 09:26:41.870945'),(102,1495669,1002,1,'{\"beatmap_hash\":\"42e49348d83bbd4fd7956d3bf1cc9084\",\"new_status\":1}','2025-08-02 09:26:41.896250'),(103,1495669,1002,1,'{\"beatmap_hash\":\"70902f82de6fdf9eeedf1a76db8ad8ea\",\"new_status\":1}','2025-08-02 09:26:41.923559'),(104,1495669,1002,1,'{\"beatmap_hash\":\"281a6f1b29c9bfd68625c8d9e12a030d\",\"new_status\":1}','2025-08-02 09:26:41.947640');
/*!40000 ALTER TABLE `event_beatmap` ENABLE KEYS */;

-- 
-- Definition of event_user
-- 

DROP TABLE IF EXISTS `event_user`;
CREATE TABLE IF NOT EXISTS `event_user` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `EventType` int NOT NULL,
  `Ip` varchar(255) NOT NULL,
  `JsonData` longtext NOT NULL,
  `Time` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_event_user_EventType_UserId` (`EventType`,`UserId`),
  KEY `IX_event_user_UserId` (`UserId`),
  KEY `IX_event_user_EventType_Ip` (`EventType`,`Ip`),
  CONSTRAINT `FK_event_user_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table event_user
-- 

/*!40000 ALTER TABLE `event_user` DISABLE KEYS */;
INSERT INTO `event_user`(`Id`,`UserId`,`EventType`,`Ip`,`JsonData`,`Time`) VALUES(1,1002,2,'8.215.16.28','{\"RegisterData\":{\"Username\":\"Yazid\",\"Email\":\"dahlahg7@gmail.com\",\"Passhash\":\"c848b5b86a1cde2e42aadc543472f5a4\",\"Country\":100,\"RegisterDate\":\"2025-08-01T16:29:58.5780123Z\"}}','2025-08-01 16:29:58.770659'),(2,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T16:30:06.7527668Z\"}}','2025-08-01 16:30:06.753637'),(3,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T17:11:29.0569074Z\"}}','2025-08-01 17:11:29.056914'),(4,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T19:21:48.2448766Z\"}}','2025-08-01 19:21:48.244882'),(5,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 EdgA/138.0.0.0\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-02T01:38:59.7000056Z\"}}','2025-08-02 01:38:59.700013'),(6,1002,0,'8.215.16.28','{\"LoginData\":\"Yazid\\nc848b5b86a1cde2e42aadc543472f5a4\\nb20250702.1|7|1|6e068d988e0adbcc9038c8c76363dbc4:00155D432004.DC97BA1EC004.DE97BA1EC003.DC97BA1EC003.DC97BA1EC007.40C2BA53A144..:665233bc4051a8c1a4348c1ba263d2c7:d76a1202a88b54be344259307dd6a08d:efe402e99547a0df14a502787ed797d4:|0\\n\"}','2025-08-02 08:47:36.555409'),(7,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-02T09:53:15.3524724Z\"}}','2025-08-02 09:53:15.352519'),(8,1002,0,'8.215.16.28','{\"LoginData\":\"Yazid\\nc848b5b86a1cde2e42aadc543472f5a4\\nb20250702.1|7|1|6e068d988e0adbcc9038c8c76363dbc4:00155D432004.DC97BA1EC004.DE97BA1EC003.DC97BA1EC003.DC97BA1EC007.40C2BA53A144..:665233bc4051a8c1a4348c1ba263d2c7:d76a1202a88b54be344259307dd6a08d:01de52ca59e0d6c8956ffee2a80019ed:|0\\n\"}','2025-08-02 12:57:57.950451'),(9,1002,0,'8.215.16.28','{\"LoginData\":\"Yazid\\nc848b5b86a1cde2e42aadc543472f5a4\\nb20250702.1|7|1|6e068d988e0adbcc9038c8c76363dbc4:00155D432004.DC97BA1EC004.DE97BA1EC003.DC97BA1EC003.DC97BA1EC007.40C2BA53A144..:665233bc4051a8c1a4348c1ba263d2c7:d76a1202a88b54be344259307dd6a08d:01de52ca59e0d6c8956ffee2a80019ed:|0\\n\"}','2025-08-02 13:01:06.571245'),(10,1002,0,'8.215.16.28','{\"LoginData\":\"Yazid\\nc848b5b86a1cde2e42aadc543472f5a4\\nb20250702.1|7|1|6e068d988e0adbcc9038c8c76363dbc4:00155D432004.DC97BA1EC004.DE97BA1EC003.DC97BA1EC003.DC97BA1EC007.40C2BA53A144..:665233bc4051a8c1a4348c1ba263d2c7:d76a1202a88b54be344259307dd6a08d:01de52ca59e0d6c8956ffee2a80019ed:|0\\n\"}','2025-08-02 14:18:46.488159'),(11,1002,0,'8.215.16.28','{\"LoginData\":\"Yazid\\nc848b5b86a1cde2e42aadc543472f5a4\\nb20250702.1|7|1|6e068d988e0adbcc9038c8c76363dbc4:00155D432004.DC97BA1EC004.DE97BA1EC003.DC97BA1EC003.DC97BA1EC007.40C2BA53A144..:665233bc4051a8c1a4348c1ba263d2c7:d76a1202a88b54be344259307dd6a08d:01de52ca59e0d6c8956ffee2a80019ed:|0\\n\"}','2025-08-02 16:02:05.086338');
/*!40000 ALTER TABLE `event_user` ENABLE KEYS */;

-- 
-- Definition of restriction
-- 

DROP TABLE IF EXISTS `restriction`;
CREATE TABLE IF NOT EXISTS `restriction` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ExecutorId` int DEFAULT NULL,
  `Reason` longtext NOT NULL,
  `Date` datetime(6) NOT NULL,
  `ExpiryDate` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_restriction_ExecutorId` (`ExecutorId`),
  KEY `IX_restriction_UserId` (`UserId`),
  CONSTRAINT `FK_restriction_user_ExecutorId` FOREIGN KEY (`ExecutorId`) REFERENCES `user` (`Id`),
  CONSTRAINT `FK_restriction_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table restriction
-- 

/*!40000 ALTER TABLE `restriction` DISABLE KEYS */;

/*!40000 ALTER TABLE `restriction` ENABLE KEYS */;

-- 
-- Definition of score
-- 

DROP TABLE IF EXISTS `score`;
CREATE TABLE IF NOT EXISTS `score` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `BeatmapId` int NOT NULL,
  `ScoreHash` longtext NOT NULL,
  `BeatmapHash` varchar(255) NOT NULL,
  `ReplayFileId` int DEFAULT NULL,
  `TotalScore` bigint NOT NULL,
  `MaxCombo` int NOT NULL,
  `Count300` int NOT NULL,
  `Count100` int NOT NULL,
  `Count50` int NOT NULL,
  `CountMiss` int NOT NULL,
  `CountKatu` int NOT NULL,
  `CountGeki` int NOT NULL,
  `Perfect` tinyint(1) NOT NULL,
  `Mods` int NOT NULL,
  `Grade` longtext NOT NULL,
  `IsPassed` tinyint(1) NOT NULL,
  `IsScoreable` tinyint(1) NOT NULL,
  `SubmissionStatus` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `WhenPlayed` datetime(6) NOT NULL,
  `OsuVersion` longtext NOT NULL,
  `BeatmapStatus` int NOT NULL,
  `ClientTime` datetime(6) NOT NULL,
  `Accuracy` double NOT NULL,
  `PerformancePoints` double NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_score_ReplayFileId` (`ReplayFileId`),
  KEY `IX_score_UserId` (`UserId`),
  KEY `IX_score_BeatmapHash` (`BeatmapHash`),
  KEY `IX_score_BeatmapId_IsScoreable_IsPassed_SubmissionStatus` (`BeatmapId`,`IsScoreable`,`IsPassed`,`SubmissionStatus`),
  KEY `IX_score_GameMode_SubmissionStatus_BeatmapStatus_WhenPlayed` (`GameMode`,`SubmissionStatus`,`BeatmapStatus`,`WhenPlayed`),
  KEY `IX_score_UserId_BeatmapId` (`UserId`,`BeatmapId`),
  KEY `IX_score_UserId_SubmissionStatus_BeatmapStatus` (`UserId`,`SubmissionStatus`,`BeatmapStatus`),
  CONSTRAINT `FK_score_user_file_ReplayFileId` FOREIGN KEY (`ReplayFileId`) REFERENCES `user_file` (`Id`),
  CONSTRAINT `FK_score_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table score
-- 

/*!40000 ALTER TABLE `score` DISABLE KEYS */;
INSERT INTO `score`(`Id`,`UserId`,`BeatmapId`,`ScoreHash`,`BeatmapHash`,`ReplayFileId`,`TotalScore`,`MaxCombo`,`Count300`,`Count100`,`Count50`,`CountMiss`,`CountKatu`,`CountGeki`,`Perfect`,`Mods`,`Grade`,`IsPassed`,`IsScoreable`,`SubmissionStatus`,`GameMode`,`WhenPlayed`,`OsuVersion`,`BeatmapStatus`,`ClientTime`,`Accuracy`,`PerformancePoints`) VALUES(1,1002,2673453,'b9a2dc705dab9e4d4a6240ef2efa7caf','2ef240b625261031062448b80786615b',NULL,4762345,409,379,10,1,8,7,45,0,72,'F',0,1,0,0,'2025-08-02 08:49:43.517966','20250702',2,'2025-08-02 08:49:41.000000',96.10552978515625,230.37732224906782),(2,1002,3963421,'af394f0df8126a64093126f336b75261','60eb1272ec54065bf3a63c42a2ebdcfc',4,5974867,463,339,3,0,0,3,61,1,72,'SH',1,1,2,0,'2025-08-02 08:50:43.935710','20250702',2,'2025-08-02 08:50:42.000000',99.41520690917969,1358.2507737828848),(3,1002,4835258,'c666fec75622f28b50d18f0b5080df50','1c8944b4071f542abfed9b2736139e62',NULL,1118451,234,161,4,0,1,2,35,0,72,'F',0,1,0,0,'2025-08-02 08:51:36.768825','20250702',2,'2025-08-02 08:51:35.000000',97.79116821289062,140.25047997079116),(4,1002,4835258,'ded5cef788c38e9233c458583d405001','1c8944b4071f542abfed9b2736139e62',NULL,1123791,234,165,1,0,2,1,37,0,72,'F',0,1,0,0,'2025-08-02 08:53:30.648237','20250702',2,'2025-08-02 08:53:29.000000',98.4126968383789,141.36962743882404),(5,1002,3855721,'ab8a02ef20808ab85940f679bd2f1f78','bdffc3f686c73e0f77b2a8ce2b5bfbb7',5,14951815,872,588,3,0,1,3,122,0,72,'A',1,1,2,0,'2025-08-02 08:55:38.728100','20250702',2,'2025-08-02 08:55:36.000000',99.49324035644531,611.4073622836069),(6,1002,4577927,'c43717921d657fdb6e2ac59f9ea286a1','9506815305a9d2e6132836b2384fdcf9',NULL,151754,67,66,0,0,1,0,23,0,72,'F',0,1,0,0,'2025-08-02 08:56:55.637662','20250702',2,'2025-08-02 08:56:54.000000',98.50746154785156,102.97402005214065),(7,1002,2014389,'1a85fa7899097da8706a01b80c833109','b3f0d4e8baa909791e5fd202e82d24b2',NULL,652082,95,252,68,10,20,22,42,0,72,'F',0,1,0,0,'2025-08-02 08:59:48.875571','20250702',2,'2025-08-02 08:59:47.000000',78.95237731933594,302.87769864246985),(8,1002,2225036,'e9d6fa6d2ebf013bd33f291f91080a47','52572619949045257f18413a6b8e5f5e',NULL,836587,195,160,1,0,1,1,30,0,72,'F',0,1,0,0,'2025-08-02 09:08:08.961348','20250702',2,'2025-08-02 09:08:07.000000',98.97119140625,123.88639438166426),(9,1002,2983479,'f75937ed489d185abf11439bfdd71a71','12442d02d25337b0086f6608d5f704b6',NULL,1640660,253,175,0,0,0,0,24,0,72,'F',0,1,0,0,'2025-08-02 09:14:46.991576','20250702',2,'2025-08-02 09:14:45.000000',100,81.27746055046399),(10,1002,4876550,'a5376838b6478dec6a11c1b9963b6b28','d69521fe4a6f61f0a8b7cd9cbc932e57',NULL,164863,72,104,12,2,8,7,13,0,72,'F',0,1,0,0,'2025-08-02 09:15:50.019350','20250702',2,'2025-08-02 09:15:48.000000',85.97883605957031,460.56204870095064),(11,1002,4924798,'9dc78ad25535eeadb4fb48887c546b20','b6b8d65d3d8a9dff236ef5cd10c49b8b',NULL,609268,139,166,10,0,9,6,32,0,72,'F',0,1,0,0,'2025-08-02 09:16:22.775791','20250702',2,'2025-08-02 09:16:21.000000',91.53153228759766,606.1324664022898),(12,1002,4885549,'1699b0d7bd310aaccc5a03d40f31127c','b8dd92057dc48f6c9dad020a94b55948',6,1882944,287,362,6,2,11,5,95,0,72,'A',1,1,2,0,'2025-08-02 09:17:41.002331','20250702',2,'2025-08-02 09:17:39.000000',95.62554931640625,554.6884112860356),(13,1002,4847819,'2a4a93cee5a24cbd30457fcad8bf9e08','7adba14645d8bcabbc9d55d1d160bfd6',NULL,135937,64,76,0,0,1,0,10,0,72,'F',0,1,0,0,'2025-08-02 09:18:06.768819','20250702',2,'2025-08-02 09:18:05.000000',98.70130157470703,125.28504514569762),(14,1002,4847819,'5a6602c86e4ac189c1bd79f9b359f400','7adba14645d8bcabbc9d55d1d160bfd6',7,4991141,432,436,5,0,3,3,72,0,72,'A',1,1,2,0,'2025-08-02 09:18:53.875716','20250702',2,'2025-08-02 09:18:52.000000',98.57357025146484,1064.1733526775881),(15,1002,1219094,'d607a4b3d9a09fb47de74fac93525b72','0a3a67271c6b9498d5cb31306e9bf69f',NULL,5028222,437,457,12,0,4,4,95,0,72,'F',0,1,0,0,'2025-08-02 09:21:02.854966','20250702',2,'2025-08-02 09:21:01.000000',97.46300506591797,228.02198884972847),(16,1002,3928577,'b370c02754754822ac37881d6e0aa74f','107f6147ec16b5b9c5d062aa52b7bed2',NULL,2891780,275,356,16,4,1,12,42,0,88,'F',0,1,0,0,'2025-08-02 09:24:49.886505','20250702',2,'2025-08-02 09:24:48.000000',96.0212173461914,297.5639758364806),(17,1002,3066156,'5f6400f22de8838d02f7b8df8195d5e8','380dd9139e5dd6babdb22882b11aa9d7',8,113687,49,69,0,0,1,0,31,0,72,'A',1,0,1,0,'2025-08-02 09:25:20.615796','20250702',0,'2025-08-02 09:25:19.000000',98.57142639160156,694.8122479610583),(18,1002,3066156,'04c25636ca0d29b3bdb0f6f434b436b5','380dd9139e5dd6babdb22882b11aa9d7',9,214924,82,68,2,0,0,2,30,1,72,'SH',1,0,1,0,'2025-08-02 09:25:35.396281','20250702',0,'2025-08-02 09:25:34.000000',98.0952377319336,753.6510501556947),(19,1002,3066156,'3288f1b3e3ae10573dd344a0d7523c77','380dd9139e5dd6babdb22882b11aa9d7',10,217308,82,69,1,0,0,1,31,1,72,'SH',1,1,2,0,'2025-08-02 09:27:43.702089','20250702',2,'2025-08-02 09:27:42.000000',99.04762268066406,781.8444146665266),(20,1002,4778695,'cf75fb9cbb330a6455e854660fa5a7ab','5b1cead69fd7b7ecf8b290fe7e00826f',NULL,61260,44,49,6,0,1,5,12,0,0,'F',0,1,0,0,'2025-08-02 13:02:21.494806','20250702',2,'2025-08-02 13:02:19.000000',91.07142639160156,50.40948628616023),(21,1002,4778695,'06fee7223ef95a4919aac5cba33c7e1a','5b1cead69fd7b7ecf8b290fe7e00826f',NULL,9849886,708,891,69,5,17,51,274,0,0,'F',0,1,0,0,'2025-08-02 13:05:05.755410','20250702',2,'2025-08-02 13:05:03.000000',93.16021728515625,376.0516368365356),(22,1002,4880186,'fa8c3804c3afe5acb6420fc31a67a310','25ac67fb351aebf9469d2f5572f68cb6',NULL,976325,159,199,4,0,1,4,46,0,16,'F',0,1,0,0,'2025-08-02 13:06:26.279097','20250702',2,'2025-08-02 13:06:24.000000',98.2026138305664,115.0802484655617),(23,1002,5098651,'669c2dde4c509796074e978e4f680aeb','8bd8828ea47a1f8daaff6a1c6b24bc29',NULL,635626,94,266,34,5,13,21,63,0,72,'F',0,1,0,0,'2025-08-02 13:08:10.062509','20250702',2,'2025-08-02 13:08:07.000000',87.47379302978516,402.42003725853425),(24,1002,4334523,'64018e79c9573b819b9a112f107ca830','e9e20b4447c96dd3371eb326270a23fc',11,2853915,193,877,34,9,30,18,158,0,72,'A',1,1,2,0,'2025-08-02 13:12:10.126464','20250702',2,'2025-08-02 13:12:07.000000',93.66666412353516,309.6867468799985),(25,1002,3057801,'662157cf31b0d47a9fa4b2ab07fef17b','f9eb0ae3b4a340f38fee392a17e18913',NULL,195472,76,134,8,1,68,1,17,0,72,'F',0,1,0,0,'2025-08-02 13:15:12.209562','20250702',5,'2025-08-02 13:15:10.000000',64.84992218017578,252.39926975192236),(26,1002,5061151,'a95afc4d5c91f3fe006e71f6cd81c72a','9d31a01f80b054bccf4c52e1d3d2e83b',12,5482809,460,410,28,1,1,21,55,0,88,'A',1,1,1,0,'2025-08-02 13:16:30.634289','20250702',2,'2025-08-02 13:16:28.000000',95.34091186523438,1359.4286821350768),(27,1002,5061151,'46f7738fd2c0bba06407890da56431ca','9d31a01f80b054bccf4c52e1d3d2e83b',13,6774040,512,417,21,2,0,17,59,1,88,'SH',1,1,2,0,'2025-08-02 13:17:18.807363','20250702',2,'2025-08-02 13:17:16.000000',96.43939208984375,1549.6508319700288),(28,1002,4978112,'21f209306089bdc3b7f3d87ea0581145','f01037a1f50b7293c8524ec1ad8cd9bf',NULL,1722962,259,163,16,3,0,11,26,0,88,'F',0,1,0,0,'2025-08-02 13:19:10.419408','20250702',2,'2025-08-02 13:19:08.000000',92.76556396484375,231.31581121753834),(29,1002,4943353,'204ba080d582483c0f3bc3e0b25eaff8','359bc79d06fc23682cf8db839f6bb15d',NULL,1352059,225,151,4,0,0,4,22,0,88,'F',0,1,0,0,'2025-08-02 13:19:45.747485','20250702',2,'2025-08-02 13:19:43.000000',98.27957153320312,173.54761106215895),(30,1002,3993306,'ffe68e91e428ad67a91b8023e77b77a5','970ec521eefb34f61d99eabf6b18e50d',NULL,713954,145,245,9,0,8,8,70,0,72,'F',0,1,0,0,'2025-08-02 13:21:00.430654','20250702',2,'2025-08-02 13:20:58.000000',94.65648651123047,96.2714458379601),(31,1002,3992108,'f1604aba2aa68f6133b8ab2111e0f6c0','e2cd9b2a4804cbc92c96464feb5898f9',NULL,1112117,155,262,33,0,11,22,39,0,72,'F',0,1,0,0,'2025-08-02 13:21:48.167922','20250702',2,'2025-08-02 13:21:45.000000',89.21568298339844,173.8316495931277),(32,1002,722844,'650d904b69c3a9e9cf9c1dd89c234a36','3fede5718ed5c79e2243cf916cd02e00',NULL,2640694,150,773,184,12,41,69,24,0,72,'F',0,1,0,0,'2025-08-02 13:23:18.842840','20250702',5,'2025-08-02 13:23:16.000000',82.80528259277344,213.01454888367772),(33,1002,722844,'9dfc510d7c6f6edcadc105ddd5ade833','3fede5718ed5c79e2243cf916cd02e00',NULL,1039708,136,333,60,3,26,24,19,0,72,'F',0,1,0,0,'2025-08-02 13:23:59.395083','20250702',5,'2025-08-02 13:23:57.000000',83.76776885986328,181.64371134588532),(34,1002,4846148,'36a1fb8f2329a3c75f893dc95fb3e1a3','a3df671b220b417c63fb45b336d30760',NULL,3067244,183,738,68,10,16,36,30,0,72,'F',0,1,0,0,'2025-08-02 13:36:40.302497','20250702',2,'2025-08-02 13:36:38.000000',91.62660217285156,354.0466516398394),(35,1002,5075617,'4900fc1d774e1022ad6e3ad59cea36f1','8f8f7f721cda0c80288087b11b21358f',14,987277,216,196,15,2,10,7,31,0,72,'B',1,1,2,0,'2025-08-02 13:39:29.588507','20250702',2,'2025-08-02 13:39:27.000000',90.28400421142578,531.9833041610608),(36,1002,4919463,'6d662479aa0a0afac343fec59d23a814','880989e45674ee4a10d49e1905ff07fd',15,3163787,271,573,34,1,26,22,143,0,72,'A',1,1,2,0,'2025-08-02 13:44:26.708664','20250702',2,'2025-08-02 13:44:23.000000',92.19242858886719,350.1990672907029),(37,1002,2872154,'3feb4ce616ad7fe6a5c1138b76a1c7bb','f239eb98ab78bfe8f2e106e6f6a056fb',NULL,28946559,1025,805,19,2,6,16,109,0,72,'F',0,1,0,0,'2025-08-02 13:46:49.885969','20250702',2,'2025-08-02 13:46:47.000000',97.55609130859375,322.9070307495693),(38,1002,4637584,'c6a286bad759c610fb3324634c0bf13b','456eb792ad94bb63e15dcecc43a5da47',16,3056364,335,499,7,0,4,6,162,0,72,'A',1,1,2,0,'2025-08-02 13:49:08.212791','20250702',2,'2025-08-02 13:49:05.000000',98.30065155029297,831.4164872074668),(39,1002,3992108,'7eeb401c3408fb2e1abb4636e519527a','e2cd9b2a4804cbc92c96464feb5898f9',NULL,266179,109,81,4,0,4,3,18,0,16,'F',0,1,0,0,'2025-08-02 13:50:07.712020','20250702',2,'2025-08-02 13:50:05.000000',92.50936126708984,34.6715443141462),(40,1002,3992108,'c875e612d671fc6b3108f1058f475712','e2cd9b2a4804cbc92c96464feb5898f9',NULL,3523658,369,288,15,2,2,13,54,0,16,'F',0,1,0,0,'2025-08-02 13:52:12.311054','20250702',2,'2025-08-02 13:52:10.000000',95.5483169555664,95.96707869647636),(41,1002,3023414,'560e2a9b67e58990bd6c503d872ebc23','99f5a61eeabb5ac5e421eef3ac6d3ed4',NULL,150860,39,153,5,0,21,5,24,0,0,'F',0,1,0,0,'2025-08-02 13:55:10.529542','20250702',2,'2025-08-02 13:52:55.000000',86.40596008300781,128.52684833853127),(42,1002,4691035,'99c1adc5e22958cbc494c25f49920462','886f3a7dd57f218ba64af08a4d12ed32',NULL,777203,162,134,5,0,1,5,21,0,72,'F',0,1,0,0,'2025-08-02 13:55:12.672183','20250702',2,'2025-08-02 13:54:17.000000',96.9047622680664,90.39959294792217),(43,1002,4691035,'562f65b959a3149038a34c9882478c36','886f3a7dd57f218ba64af08a4d12ed32',NULL,92329,53,48,1,0,3,1,7,0,72,'F',0,1,0,0,'2025-08-02 13:55:12.813003','20250702',2,'2025-08-02 13:54:27.000000',92.94871520996094,38.782651214269116),(44,1002,4800049,'27313e5104cd015708f7cc055f83f55b','31d14941decd0d7167a8ef7830f1767b',NULL,580251,151,133,0,0,1,0,31,0,72,'F',0,1,0,0,'2025-08-02 13:55:42.100493','20250702',2,'2025-08-02 13:55:40.000000',99.25373077392578,462.30708910012936),(45,1002,4800049,'0bcb6a3c5b823cd36eda780740b512dd','31d14941decd0d7167a8ef7830f1767b',NULL,96970,60,55,1,0,2,1,6,0,72,'F',0,1,0,0,'2025-08-02 13:55:55.179752','20250702',2,'2025-08-02 13:55:53.000000',95.40229797363281,195.22149857945848),(46,1002,4800049,'4129fb8e17925842ade6f5c4d8a837c7','31d14941decd0d7167a8ef7830f1767b',17,382407,85,164,2,0,3,2,39,0,72,'A',1,1,2,0,'2025-08-02 13:56:19.899381','20250702',2,'2025-08-02 13:56:18.000000',97.43589782714844,576.4605154793579),(47,1002,320180,'ce13e716f90b16d1ecb8c45f95522cab','802229de647a4b7b9ee02e62de87ee19',NULL,2275565,288,217,1,0,0,1,56,0,72,'F',0,1,0,0,'2025-08-02 13:57:37.844377','20250702',5,'2025-08-02 13:57:35.000000',99.6941909790039,76.35455742370533),(48,1002,320180,'b3cad3bdc8373a570a7be087ee3faa1e','802229de647a4b7b9ee02e62de87ee19',NULL,383206,117,89,2,0,1,2,24,0,72,'F',0,1,0,0,'2025-08-02 13:57:56.872566','20250702',5,'2025-08-02 13:57:55.000000',97.4637680053711,40.84979749147602),(49,1002,2663986,'366d0eafd75f7139973f7cf013fad7a2','4a4dd5f39b232f7c14a658d2eb217f38',NULL,3968174,379,290,5,0,2,2,48,0,72,'F',0,1,0,0,'2025-08-02 14:00:24.309696','20250702',2,'2025-08-02 14:00:22.000000',98.20426177978516,164.61110217945483),(50,1002,1241370,'088c31c5b8902f2ed9c0dca1199c9083','cd9fd3bf3098a0d0aa6b72456a2972a6',NULL,9557612,553,490,6,0,1,6,95,0,72,'F',0,1,0,0,'2025-08-02 14:02:12.282160','20250702',2,'2025-08-02 14:01:54.000000',98.99396514892578,250.16191623280855),(51,1002,1241370,'16610cf8a32eb0eed13837a01d281dd2','cd9fd3bf3098a0d0aa6b72456a2972a6',NULL,13078438,459,943,10,0,4,10,170,0,72,'F',0,1,0,0,'2025-08-02 14:03:44.201863','20250702',2,'2025-08-02 14:03:41.000000',98.88540649414062,363.6997879792766),(52,1002,1869933,'f70959e3c08de2141bd8bd18b2a3ff02','527bc63f13471981010066ad57d75a02',18,2191647,289,252,4,0,5,4,65,0,72,'A',1,1,2,0,'2025-08-02 14:04:51.193632','20250702',2,'2025-08-02 14:04:49.000000',97.06257629394531,502.793920631311),(53,1002,4277541,'976f9a2eb81ee77257837a15d04e4f3f','522b5a5077437d2083f1a53de98c4dd7',19,25711808,1067,802,3,0,0,3,80,0,72,'SH',1,1,2,0,'2025-08-02 14:21:07.017393','20250702',2,'2025-08-02 14:21:04.000000',99.75155639648438,971.3025045490652),(54,1002,4277533,'344bd1002c2f4235532df37180ca0785','45ec2108ce7d2092973c70f1e22e9e99',20,40160680,1223,931,12,0,1,11,144,0,72,'A',1,1,2,0,'2025-08-02 14:22:57.065650','20250702',2,'2025-08-02 14:22:54.000000',99.0466079711914,1131.290314539598),(55,1002,3584736,'123cdb76efce3662173e5d1f8fe2ab4b','8583d1e8b6cbda19bad9402c1364e449',NULL,464729,140,116,1,0,9,1,36,0,72,'F',0,1,0,0,'2025-08-02 14:24:48.227130','20250702',2,'2025-08-02 14:24:46.000000',92.32804107666016,256.5955831320076),(56,1002,2726492,'1f3f8fb5eec458ef2252299fe82b0572','e4ff7df1cd6c9c442734ba64529c8399',NULL,2062605,275,237,1,0,1,1,42,0,72,'F',0,1,0,0,'2025-08-02 14:28:00.841091','20250702',2,'2025-08-02 14:27:58.000000',99.30265045166016,276.22863227275155),(57,1002,4985374,'1a1f9947fc9fad2436b05a28b72d8209','1881deafa2a0f2f10853534f2c286b91',21,7727413,532,399,2,0,0,2,88,0,72,'SH',1,1,2,0,'2025-08-02 14:31:38.835357','20250702',2,'2025-08-02 14:31:36.000000',99.66749572753906,0),(58,1002,4277533,'195477a75d1192e2fce15d7bbc13a415','45ec2108ce7d2092973c70f1e22e9e99',NULL,14104088,606,741,4,1,1,4,127,0,72,'F',0,1,0,0,'2025-08-02 14:33:55.052937','20250702',2,'2025-08-02 14:33:53.000000',99.39759063720703,475.28779532835404),(59,1002,5054371,'345239ca7d4cec3d7a12bad50316cd0c','0d9271f666d3f1b662b54f141718cf60',22,5884322,403,482,4,1,1,3,56,0,72,'A',1,1,2,0,'2025-08-02 14:35:06.044421','20250702',2,'2025-08-02 14:35:03.000000',99.07786560058594,1091.3218983658526),(60,1002,884664,'3667407b3713dbe5e7212dda6af64020','87c23892caf52ac3866e7ab7f7802956',NULL,1039701,182,189,1,0,3,0,32,0,72,'F',0,1,0,0,'2025-08-02 14:37:55.599717','20250702',2,'2025-08-02 14:37:53.000000',98.10017395019531,123.7872104182456),(61,1002,5035336,'d6af57e263b0ffd88eb0ef99ccdb0bc7','9f1a2d8b9a1dc494a217cd8f1d7694c4',23,5387246,510,373,1,0,2,1,81,0,72,'A',1,1,2,0,'2025-08-02 16:10:57.163137','20250702',2,'2025-08-02 16:10:54.000000',99.29077911376953,0),(62,1002,1494828,'a093dd7ab4b64936d69b520f4a8b7591','257099a7bc15792928a55c1a8510e934',NULL,5169322,333,571,20,1,6,14,96,0,72,'F',0,1,0,0,'2025-08-02 16:12:52.971955','20250702',2,'2025-08-02 16:12:50.000000',96.62764739990234,227.99182307259912),(63,1002,4704022,'4c00d61cd281e5aa9166f611e97c1e47','bb0ab87debbf0a94967c68ccb83fbd96',24,127357100,2407,1833,3,0,0,3,237,1,72,'SH',1,1,2,0,'2025-08-02 16:15:53.259678','20250702',2,'2025-08-02 16:15:51.000000',99.89106750488281,1757.7697133491358),(64,1002,4064320,'527571bbc012d2cb17c0561f77880604','a3d04c701154ef274e4fde58a574bc70',NULL,502545,120,123,1,0,1,0,15,0,72,'F',0,1,0,0,'2025-08-02 16:31:47.882703','20250702',2,'2025-08-02 16:31:46.000000',98.66666412353516,103.36124273951523),(65,1002,4064320,'dd1711a2931c829836b9558ed2fc88bd','a3d04c701154ef274e4fde58a574bc70',NULL,1627839,225,211,3,0,1,3,22,0,72,'F',0,1,0,0,'2025-08-02 16:32:06.833195','20250702',2,'2025-08-02 16:32:05.000000',98.60465240478516,155.51589891533843),(66,1002,4064320,'9df7132daaaa8e245dae82a53cd23071','a3d04c701154ef274e4fde58a574bc70',NULL,1657752,226,218,0,0,4,0,25,0,72,'F',0,1,0,0,'2025-08-02 16:32:26.232655','20250702',2,'2025-08-02 16:32:24.000000',98.19819641113281,157.65438104725325),(67,1002,4064320,'79061bd369a4d4d9d5c565d397cf7669','a3d04c701154ef274e4fde58a574bc70',NULL,274544,91,87,3,0,2,2,7,0,72,'F',0,1,0,0,'2025-08-02 16:32:38.444720','20250702',2,'2025-08-02 16:32:36.000000',95.65217590332031,83.37223422241769),(68,1002,4064320,'53f97c8a65f45fd5b852814345a19899','a3d04c701154ef274e4fde58a574bc70',NULL,10905395,595,521,4,0,18,3,61,0,72,'F',0,1,0,0,'2025-08-02 16:33:42.442219','20250702',2,'2025-08-02 16:33:24.000000',96.19398498535156,185.37119622471945),(69,1002,3665005,'f0cb0b9dfaa8f0958d38c58239c0aed7','0e38c93a039ce202e33e26afbf747565',25,144264565,2408,1670,6,0,0,5,316,1,72,'SH',1,1,2,0,'2025-08-02 16:36:59.147367','20250702',2,'2025-08-02 16:36:56.000000',99.76133728027344,1204.3538794091407),(70,1002,1695991,'a178a78ba005615a0098193383e8c808','2c6b18605486f1738f41873c4c0fec5b',26,48373131,1366,972,23,0,0,22,188,1,72,'SH',1,1,2,0,'2025-08-02 16:40:13.337270','20250702',2,'2025-08-02 16:40:10.000000',98.4589614868164,1189.125486449773);
/*!40000 ALTER TABLE `score` ENABLE KEYS */;

-- 
-- Definition of user_favourite_beatmap
-- 

DROP TABLE IF EXISTS `user_favourite_beatmap`;
CREATE TABLE IF NOT EXISTS `user_favourite_beatmap` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `BeatmapSetId` int NOT NULL,
  `DateAdded` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_favourite_beatmap_UserId` (`UserId`),
  KEY `IX_user_favourite_beatmap_UserId_BeatmapSetId` (`UserId`,`BeatmapSetId`),
  CONSTRAINT `FK_user_favourite_beatmap_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_favourite_beatmap
-- 

/*!40000 ALTER TABLE `user_favourite_beatmap` DISABLE KEYS */;

/*!40000 ALTER TABLE `user_favourite_beatmap` ENABLE KEYS */;

-- 
-- Definition of user_file
-- 

DROP TABLE IF EXISTS `user_file`;
CREATE TABLE IF NOT EXISTS `user_file` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OwnerId` int NOT NULL,
  `Path` longtext NOT NULL,
  `Type` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_file_OwnerId` (`OwnerId`),
  KEY `IX_user_file_OwnerId_Type` (`OwnerId`,`Type`),
  CONSTRAINT `FK_user_file_user_OwnerId` FOREIGN KEY (`OwnerId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_file
-- 

/*!40000 ALTER TABLE `user_file` DISABLE KEYS */;
INSERT INTO `user_file`(`Id`,`OwnerId`,`Path`,`Type`,`CreatedAt`,`UpdatedAt`) VALUES(1,1001,'Files/Avatars/1.png',1,'2025-08-01 10:02:45.591213','2025-08-01 10:02:45.591213'),(2,1002,'Files/Banners/1002.jpg',2,'2025-08-01 17:05:47.437604','2025-08-01 17:05:47.437605'),(3,1002,'Files/Avatars/1002.jpg',1,'2025-08-01 17:08:46.244416','2025-08-01 17:08:46.244416'),(4,1002,'Files/Replays/1002-2025-08-02_08-50-44.osr',3,'2025-08-02 08:50:44.971933','2025-08-02 08:50:44.971933'),(5,1002,'Files/Replays/1002-2025-08-02_08-55-40.osr',3,'2025-08-02 08:55:40.116405','2025-08-02 08:55:40.116405'),(6,1002,'Files/Replays/1002-2025-08-02_09-17-42.osr',3,'2025-08-02 09:17:42.149487','2025-08-02 09:17:42.149488'),(7,1002,'Files/Replays/1002-2025-08-02_09-18-53.osr',3,'2025-08-02 09:18:53.888341','2025-08-02 09:18:53.888341'),(8,1002,'Files/Replays/1002-2025-08-02_09-25-21.osr',3,'2025-08-02 09:25:21.552933','2025-08-02 09:25:21.552933'),(9,1002,'Files/Replays/1002-2025-08-02_09-25-35.osr',3,'2025-08-02 09:25:35.413464','2025-08-02 09:25:35.413464'),(10,1002,'Files/Replays/1002-2025-08-02_09-27-43.osr',3,'2025-08-02 09:27:43.709520','2025-08-02 09:27:43.709520'),(11,1002,'Files/Replays/1002-2025-08-02_13-12-11.osr',3,'2025-08-02 13:12:11.543361','2025-08-02 13:12:11.543361'),(12,1002,'Files/Replays/1002-2025-08-02_13-16-31.osr',3,'2025-08-02 13:16:31.763002','2025-08-02 13:16:31.763002'),(13,1002,'Files/Replays/1002-2025-08-02_13-17-18.osr',3,'2025-08-02 13:17:18.824647','2025-08-02 13:17:18.824647'),(14,1002,'Files/Replays/1002-2025-08-02_13-39-30.osr',3,'2025-08-02 13:39:30.318779','2025-08-02 13:39:30.318779'),(15,1002,'Files/Replays/1002-2025-08-02_13-44-28.osr',3,'2025-08-02 13:44:28.734967','2025-08-02 13:44:28.734967'),(16,1002,'Files/Replays/1002-2025-08-02_13-49-09.osr',3,'2025-08-02 13:49:09.707921','2025-08-02 13:49:09.707921'),(17,1002,'Files/Replays/1002-2025-08-02_13-56-19.osr',3,'2025-08-02 13:56:19.907448','2025-08-02 13:56:19.907448'),(18,1002,'Files/Replays/1002-2025-08-02_14-04-52.osr',3,'2025-08-02 14:04:52.161495','2025-08-02 14:04:52.161495'),(19,1002,'Files/Replays/1002-2025-08-02_14-21-08.osr',3,'2025-08-02 14:21:08.473969','2025-08-02 14:21:08.473969'),(20,1002,'Files/Replays/1002-2025-08-02_14-22-58.osr',3,'2025-08-02 14:22:58.441772','2025-08-02 14:22:58.441772'),(21,1002,'Files/Replays/1002-2025-08-02_14-31-40.osr',3,'2025-08-02 14:31:40.289522','2025-08-02 14:31:40.289522'),(22,1002,'Files/Replays/1002-2025-08-02_14-35-07.osr',3,'2025-08-02 14:35:07.810175','2025-08-02 14:35:07.810175'),(23,1002,'Files/Replays/1002-2025-08-02_16-10-57.osr',3,'2025-08-02 16:10:57.191140','2025-08-02 16:10:57.191140'),(24,1002,'Files/Replays/1002-2025-08-02_16-15-54.osr',3,'2025-08-02 16:15:54.958765','2025-08-02 16:15:54.958765'),(25,1002,'Files/Replays/1002-2025-08-02_16-37-00.osr',3,'2025-08-02 16:37:00.627703','2025-08-02 16:37:00.627703'),(26,1002,'Files/Replays/1002-2025-08-02_16-40-14.osr',3,'2025-08-02 16:40:14.698410','2025-08-02 16:40:14.698410');
/*!40000 ALTER TABLE `user_file` ENABLE KEYS */;

-- 
-- Definition of user_grades
-- 

DROP TABLE IF EXISTS `user_grades`;
CREATE TABLE IF NOT EXISTS `user_grades` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `CountXH` int NOT NULL,
  `CountX` int NOT NULL,
  `CountSH` int NOT NULL,
  `CountS` int NOT NULL,
  `CountA` int NOT NULL,
  `CountB` int NOT NULL,
  `CountC` int NOT NULL,
  `CountD` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_grades_UserId_GameMode` (`UserId`,`GameMode`),
  CONSTRAINT `FK_user_grades_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_grades
-- 

/*!40000 ALTER TABLE `user_grades` DISABLE KEYS */;
INSERT INTO `user_grades`(`Id`,`UserId`,`GameMode`,`CountXH`,`CountX`,`CountSH`,`CountS`,`CountA`,`CountB`,`CountC`,`CountD`) VALUES(1,1001,0,0,0,0,0,0,0,0,0),(2,1002,0,0,0,8,0,11,1,0,0),(3,1001,4,0,0,0,0,0,0,0,0),(4,1001,8,0,0,0,0,0,0,0,0),(5,1001,12,0,0,0,0,0,0,0,0),(6,1002,1,0,0,0,0,0,0,0,0),(7,1002,2,0,0,0,0,0,0,0,0),(8,1002,3,0,0,0,0,0,0,0,0),(9,1002,4,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `user_grades` ENABLE KEYS */;

-- 
-- Definition of user_inventory_item
-- 

DROP TABLE IF EXISTS `user_inventory_item`;
CREATE TABLE IF NOT EXISTS `user_inventory_item` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ItemType` int NOT NULL,
  `Quantity` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_inventory_item_UserId_ItemType` (`UserId`,`ItemType`),
  CONSTRAINT `FK_user_inventory_item_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_inventory_item
-- 

/*!40000 ALTER TABLE `user_inventory_item` DISABLE KEYS */;
INSERT INTO `user_inventory_item`(`Id`,`UserId`,`ItemType`,`Quantity`) VALUES(1,1002,0,10);
/*!40000 ALTER TABLE `user_inventory_item` ENABLE KEYS */;

-- 
-- Definition of user_medals
-- 

DROP TABLE IF EXISTS `user_medals`;
CREATE TABLE IF NOT EXISTS `user_medals` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `MedalId` int NOT NULL,
  `UnlockedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_medals_UserId` (`UserId`),
  CONSTRAINT `FK_user_medals_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_medals
-- 

/*!40000 ALTER TABLE `user_medals` DISABLE KEYS */;
INSERT INTO `user_medals`(`Id`,`UserId`,`MedalId`,`UnlockedAt`) VALUES(1,1002,10,'2025-08-02 08:50:45.456297'),(2,1002,20,'2025-08-02 08:50:45.478025'),(3,1002,92,'2025-08-02 08:50:45.492203'),(4,1002,94,'2025-08-02 08:50:45.501310'),(5,1002,7,'2025-08-02 08:55:40.196003'),(6,1002,21,'2025-08-02 08:55:40.212357'),(7,1002,22,'2025-08-02 08:55:40.225440'),(8,1002,9,'2025-08-02 09:17:42.275792'),(9,1002,8,'2025-08-02 09:27:43.785745'),(10,1002,18,'2025-08-02 09:27:43.796111'),(11,1002,101,'2025-08-02 13:12:12.081224'),(12,1002,91,'2025-08-02 13:16:31.958764'),(13,1002,23,'2025-08-02 14:21:08.593896'),(14,1002,5,'2025-08-02 16:10:57.631297'),(15,1002,19,'2025-08-02 16:15:55.049869'),(16,1002,24,'2025-08-02 16:15:55.065321');
/*!40000 ALTER TABLE `user_medals` ENABLE KEYS */;

-- 
-- Definition of user_metadata
-- 

DROP TABLE IF EXISTS `user_metadata`;
CREATE TABLE IF NOT EXISTS `user_metadata` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `Playstyle` int NOT NULL,
  `Location` varchar(32) NOT NULL,
  `Interest` varchar(32) NOT NULL,
  `Occupation` varchar(32) NOT NULL,
  `Telegram` varchar(32) NOT NULL,
  `Twitch` varchar(32) NOT NULL,
  `Twitter` varchar(32) NOT NULL,
  `Discord` varchar(32) NOT NULL,
  `Website` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_metadata_UserId` (`UserId`),
  CONSTRAINT `FK_user_metadata_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_metadata
-- 

/*!40000 ALTER TABLE `user_metadata` DISABLE KEYS */;
INSERT INTO `user_metadata`(`Id`,`UserId`,`Playstyle`,`Location`,`Interest`,`Occupation`,`Telegram`,`Twitch`,`Twitter`,`Discord`,`Website`) VALUES(1,1001,0,'','','','','','','',''),(2,1002,0,'','','','','','','','');
/*!40000 ALTER TABLE `user_metadata` ENABLE KEYS */;

-- 
-- Definition of user_relationship
-- 

DROP TABLE IF EXISTS `user_relationship`;
CREATE TABLE IF NOT EXISTS `user_relationship` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `TargetId` int NOT NULL,
  `Relation` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_relationship_TargetId` (`TargetId`),
  KEY `IX_user_relationship_UserId_TargetId` (`UserId`,`TargetId`),
  CONSTRAINT `FK_user_relationship_user_TargetId` FOREIGN KEY (`TargetId`) REFERENCES `user` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_user_relationship_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_relationship
-- 

/*!40000 ALTER TABLE `user_relationship` DISABLE KEYS */;
INSERT INTO `user_relationship`(`Id`,`UserId`,`TargetId`,`Relation`) VALUES(1,1002,1001,0),(2,1001,1002,0);
/*!40000 ALTER TABLE `user_relationship` ENABLE KEYS */;

-- 
-- Definition of user_stats
-- 

DROP TABLE IF EXISTS `user_stats`;
CREATE TABLE IF NOT EXISTS `user_stats` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `Accuracy` double NOT NULL,
  `TotalScore` bigint NOT NULL,
  `RankedScore` bigint NOT NULL,
  `PlayCount` int NOT NULL,
  `PerformancePoints` double NOT NULL,
  `MaxCombo` int NOT NULL,
  `PlayTime` int NOT NULL,
  `TotalHits` int NOT NULL,
  `BestGlobalRank` bigint DEFAULT NULL,
  `BestGlobalRankDate` datetime(6) DEFAULT NULL,
  `BestCountryRank` bigint DEFAULT NULL,
  `BestCountryRankDate` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_stats_UserId_GameMode` (`UserId`,`GameMode`),
  KEY `IX_user_stats_UserId` (`UserId`),
  CONSTRAINT `FK_user_stats_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_stats
-- 

/*!40000 ALTER TABLE `user_stats` DISABLE KEYS */;
INSERT INTO `user_stats`(`Id`,`UserId`,`GameMode`,`Accuracy`,`TotalScore`,`RankedScore`,`PlayCount`,`PerformancePoints`,`MaxCombo`,`PlayTime`,`TotalHits`,`BestGlobalRank`,`BestGlobalRankDate`,`BestCountryRank`,`BestCountryRankDate`) VALUES(1,1001,0,0,0,0,0,0,0,0,0,1,'2025-08-01 11:03:58.602154',1,'2025-08-01 11:03:58.602195'),(4,1002,0,97.95799676265469,602093768,452293777,70,12239.112445288707,2408,4261468,27282,1,'2025-08-02 08:50:45.055998',1,'2025-08-01 16:29:58.668351'),(5,1002,1,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.680813',1,'2025-08-01 16:29:58.680814'),(6,1002,2,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.686951',1,'2025-08-01 16:29:58.686952'),(7,1002,3,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.691687',1,'2025-08-01 16:29:58.691688'),(8,1002,4,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.698396',1,'2025-08-01 16:29:58.698397'),(9,1002,5,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.703255',1,'2025-08-01 16:29:58.703256'),(10,1002,6,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.708118',1,'2025-08-01 16:29:58.708119'),(11,1002,8,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.712848',1,'2025-08-01 16:29:58.712848'),(12,1002,12,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.717615',1,'2025-08-01 16:29:58.717616'),(13,1002,13,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.722200',1,'2025-08-01 16:29:58.722201'),(14,1002,14,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.726792',1,'2025-08-01 16:29:58.726793'),(15,1002,15,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.731247',1,'2025-08-01 16:29:58.731248'),(16,1001,4,0,0,0,0,0,0,0,0,1,'2025-08-02 03:45:57.371411',1,'2025-08-02 03:45:57.371489'),(17,1001,8,0,0,0,0,0,0,0,0,1,'2025-08-02 03:45:58.273531',1,'2025-08-02 03:45:58.273532'),(18,1001,12,0,0,0,0,0,0,0,0,1,'2025-08-02 03:45:58.648774',1,'2025-08-02 03:45:58.648775');
/*!40000 ALTER TABLE `user_stats` ENABLE KEYS */;

-- 
-- Definition of user_stats_snapshot
-- 

DROP TABLE IF EXISTS `user_stats_snapshot`;
CREATE TABLE IF NOT EXISTS `user_stats_snapshot` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `SnapshotsJson` longtext NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_stats_snapshot_UserId_GameMode` (`UserId`,`GameMode`),
  CONSTRAINT `FK_user_stats_snapshot_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_stats_snapshot
-- 

/*!40000 ALTER TABLE `user_stats_snapshot` DISABLE KEYS */;
INSERT INTO `user_stats_snapshot`(`Id`,`UserId`,`GameMode`,`SnapshotsJson`) VALUES(1,1001,0,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6491957Z\"},{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.0809207Z\"}]'),(2,1002,0,'[{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6611117Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":12239.112445288707,\"SavedAt\":\"2025-08-02T23:59:15.0685422Z\"}]'),(3,1002,1,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6787583Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.0926509Z\"}]'),(4,1002,2,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6968545Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1046872Z\"}]'),(5,1002,3,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7132513Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1143603Z\"}]'),(6,1002,4,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7313849Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1243442Z\"}]'),(7,1002,5,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7487522Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1410912Z\"}]'),(8,1002,6,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7669478Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1534662Z\"}]'),(9,1002,8,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7859005Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1631681Z\"}]'),(10,1002,12,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8046673Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1794784Z\"}]'),(11,1002,13,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8235054Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1966899Z\"}]'),(12,1002,14,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8421924Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.2062878Z\"}]'),(13,1002,15,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8599926Z\"},{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.2161742Z\"}]'),(14,1001,4,'[{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1310874Z\"}]'),(15,1001,8,'[{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.16986Z\"}]'),(16,1001,12,'[{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-02T23:59:15.1866803Z\"}]');
/*!40000 ALTER TABLE `user_stats_snapshot` ENABLE KEYS */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2025-08-03 03:00:12
-- Total time: 0:0:0:0:179 (d:h:m:s:ms)
