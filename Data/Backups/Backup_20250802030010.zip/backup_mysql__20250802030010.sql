-- MySqlBackup.NET 2.3.9.0
-- Dump Time: 2025-08-02 03:00:10
-- --------------------------------------
-- Server version 9.4.0 MySQL Community Server - GPL


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of __EFMigrationsHistory
-- 

DROP TABLE IF EXISTS `__EFMigrationsHistory`;
CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
  `MigrationId` varchar(150) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table __EFMigrationsHistory
-- 

/*!40000 ALTER TABLE `__EFMigrationsHistory` DISABLE KEYS */;
INSERT INTO `__EFMigrationsHistory`(`MigrationId`,`ProductVersion`) VALUES('20250327193326_MigrateToMySQL','8.0.11'),('20250330181953_AddUserGrades','8.0.11'),('20250403173344_AddCustomBeatmapStatuses','8.0.11'),('20250426214100_OptimizeIndexesUsages','8.0.11'),('20250427104756_AddDbIndexForFilterValidScores','8.0.11'),('20250506223339_AddDefaultGamemodeToUser','8.0.11'),('20250508213243_AddUserMetadataTable','8.0.11'),('20250509040239_AddUserRelationshipTable','8.0.11'),('20250509040446_MigrateUsersFriendsToRelationshipTable','8.0.11'),('20250509042335_RemoveOldUserStringFieldInUser','8.0.11'),('20250510012606_RevertRemovingNullableFromUserStatsBestValues','8.0.11'),('20250510012726_FixAllBadBestValuesForUserStats','8.0.11'),('20250512014617_AddUserInventoryItemAndBeatmapHypes','8.0.11'),('20250512014640_AddDefaultWeeklyUserHypesInTheirInventory','8.0.11'),('20250519134402_UseWebBeatmapStatusForCustomStatuses','8.0.11'),('20250520134458_AddBeatmapEvents','8.0.11'),('20250602141333_ClearUserStatsDuplicates','8.0.11'),('20250602141359_MakeUserStatsIndexUnique','8.0.11');
/*!40000 ALTER TABLE `__EFMigrationsHistory` ENABLE KEYS */;

-- 
-- Definition of medal_file
-- 

DROP TABLE IF EXISTS `medal_file`;
CREATE TABLE IF NOT EXISTS `medal_file` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Path` longtext NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table medal_file
-- 

/*!40000 ALTER TABLE `medal_file` DISABLE KEYS */;
INSERT INTO `medal_file`(`Id`,`Path`,`CreatedAt`) VALUES(1,'Files/Medals/all-secret-thisdjisfire.png','2025-08-01 10:02:45.148124'),(2,'Files/Medals/all-secret-heat-abnormal.png','2025-08-01 10:02:45.278570');
/*!40000 ALTER TABLE `medal_file` ENABLE KEYS */;

-- 
-- Definition of medal
-- 

DROP TABLE IF EXISTS `medal`;
CREATE TABLE IF NOT EXISTS `medal` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` longtext NOT NULL,
  `Description` longtext NOT NULL,
  `GameMode` tinyint unsigned DEFAULT NULL,
  `Category` int NOT NULL,
  `FileUrl` longtext,
  `FileId` int DEFAULT NULL,
  `Condition` longtext NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_medal_Category` (`Category`),
  KEY `IX_medal_FileId` (`FileId`),
  KEY `IX_medal_GameMode` (`GameMode`),
  CONSTRAINT `FK_medal_medal_file_FileId` FOREIGN KEY (`FileId`) REFERENCES `medal_file` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table medal
-- 

/*!40000 ALTER TABLE `medal` DISABLE KEYS */;
INSERT INTO `medal`(`Id`,`Name`,`Description`,`GameMode`,`Category`,`FileUrl`,`FileId`,`Condition`) VALUES(1,'Rising Star','Can''t go forward without the first steps.',0,4,'osu-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(2,'Constellation Prize','Definitely not a consolation prize. Now things start getting hard!',0,4,'osu-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(3,'Building Confidence','Oh, you''ve SO got this.',0,4,'osu-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(4,'Insanity Approaches','You''re not twitching, you''re just ready.',0,4,'osu-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(5,'These Clarion Skies','Everything seems so clear now.',0,4,'osu-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(6,'Above and Beyond','A cut above the rest.',0,4,'osu-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(7,'Supremacy','All marvel before your prowess.',0,4,'osu-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(8,'Absolution','My god, you''re full of stars!',0,4,'osu-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(9,'Event Horizon','No force dares to pull you under.',0,4,'osu-skill-pass-9',NULL,'beatmap.DifficultyRating >= 9 && beatmap.DifficultyRating < 10'),(10,'Phantasm','Fevered is your passion, extraordinary is your skill.',0,4,'osu-skill-pass-10',NULL,'beatmap.DifficultyRating >= 10 && beatmap.DifficultyRating < 11'),(11,'Totality','All the notes. Every single one.',0,4,'osu-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(12,'Business As Usual','Two to go, please.',0,4,'osu-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(13,'Building Steam','Hey, this isn''t so bad.',0,4,'osu-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(14,'Moving Forward','Bet you feel good about that.',0,4,'osu-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(15,'Paradigm Shift','Surprisingly difficult.',0,4,'osu-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(16,'Anguish Quelled','Don''t choke.',0,4,'osu-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(17,'Never Give Up','Excellence is its own reward.',0,4,'osu-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(18,'Aberration','They said it couldn''t be done. They were wrong.',0,4,'osu-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(19,'Chosen','Reign among the Prometheans, where you belong.',0,4,'osu-skill-fc-9',NULL,'beatmap.DifficultyRating >= 9 && beatmap.DifficultyRating < 10 && score.Perfect'),(20,'Unfathomable','You have no equal.',0,4,'osu-skill-fc-10',NULL,'beatmap.DifficultyRating >= 10 && beatmap.DifficultyRating < 11 && score.Perfect'),(21,'500 Combo','500 big ones! You''re moving up in the world!',0,4,'osu-combo-500',NULL,'score.MaxCombo >= 500'),(22,'750 Combo','750 notes back to back? Woah.',0,4,'osu-combo-750',NULL,'score.MaxCombo >= 750'),(23,'1,000 Combo','A thousand reasons why you rock at this game.',0,4,'osu-combo-1000',NULL,'score.MaxCombo >= 1000'),(24,'2,000 Combo','Nothing can stop you now.',0,4,'osu-combo-2000',NULL,'score.MaxCombo >= 2000'),(25,'5,000 Plays','There''s a lot more where that came from.',0,4,'osu-plays-5000',NULL,'user.PlayCount >= 5000'),(26,'15,000 Plays','Must.. click.. circles..',0,4,'osu-plays-15000',NULL,'user.PlayCount >= 15000'),(27,'25,000 Plays','There''s no going back.',0,4,'osu-plays-25000',NULL,'user.PlayCount >= 25000'),(28,'50,000 Plays','You''re here forever.',0,4,'osu-plays-50000',NULL,'user.PlayCount >= 50000'),(29,'My First Don','Marching to the beat of your own drum. Literally.',1,4,'taiko-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(30,'Katsu Katsu Katsu','Hora! Ikuzo!',1,4,'taiko-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(31,'Not Even Trying','Muzukashii? Not even.',1,4,'taiko-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(32,'Face Your Demons','The first trials are now behind you, but are you a match for the Oni?',1,4,'taiko-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(33,'The Demon Within','No rest for the wicked.',1,4,'taiko-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(34,'Drumbreaker','Too strong.',1,4,'taiko-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(35,'The Godfather','You are the Don of Dons.',1,4,'taiko-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(36,'Rhythm Incarnate','Feel the beat. Become the beat.',1,4,'taiko-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(37,'Keeping Time','Don, then katsu. Don, then katsu..',1,4,'taiko-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(38,'To Your Own Beat','Straight and steady.',1,4,'taiko-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(39,'Big Drums','Bigger scores to match.',1,4,'taiko-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(40,'Adversity Overcome','Difficult? Not for you.',1,4,'taiko-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(41,'Demonslayer','An Oni felled forevermore.',1,4,'taiko-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(42,'''Rhythm''s Call','Heralding true skill.',1,4,'taiko-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(43,'Time Everlasting','Not a single beat escapes you.',1,4,'taiko-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(44,'The Drummer''s Throne','Percussive brilliance befitting royalty alone.',1,4,'taiko-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(45,'30,000 Drum Hits','Did that drum have a face?',1,4,'taiko-hits-30000',NULL,'user.TotalHits >= 30000'),(46,'300,000 Drum Hits','The rhythm never stops.',1,4,'taiko-hits-300000',NULL,'user.TotalHits >= 300000'),(47,'3,000,000 Drum Hits','Truly, the Don of dons.',1,4,'taiko-hits-3000000',NULL,'user.TotalHits >= 3000000'),(48,'30,000,000 Drum Hits','Your rhythm, eternal.',1,4,'taiko-hits-30000000',NULL,'user.TotalHits >= 30000000'),(49,'A Slice Of Life','Hey, this fruit catching business isn''t bad.',2,4,'fruits-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(50,'Dashing Ever Forward','Fast is how you do it.',2,4,'fruits-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(51,'Zesty Disposition','No scurvy for you, not with that much fruit.',2,4,'fruits-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(52,'Hyperdash ON!','Time and distance is no obstacle to you.',2,4,'fruits-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(53,'It''s Raining Fruit','And you can catch them all.',2,4,'fruits-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(54,'Fruit Ninja','Legendary techniques.',2,4,'fruits-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(55,'Dreamcatcher','No fruit, only dreams now.',2,4,'fruits-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(56,'Lord of the Catch','Your kingdom kneels before you.',2,4,'fruits-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(57,'Sweet And Sour','Apples and oranges, literally.',2,4,'fruits-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(58,'Reaching The Core','The seeds of future success.',2,4,'fruits-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(59,'Clean Platter','Clean only of failure. It is completely full, otherwise.',2,4,'fruits-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(60,'Between The Rain','No umbrella needed.',2,4,'fruits-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(61,'Addicted','That was an overdose?',2,4,'fruits-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(62,'Quickening','A dash above normal limits.',2,4,'fruits-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(63,'Supersonic','Faster than is reasonably necessary.',2,4,'fruits-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(64,'Dashing Scarlet','Speed beyond mortal reckoning.',2,4,'fruits-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(65,'Catch 20,000 fruits','That is a lot of dietary fiber.',2,4,'fruits-hits-20000',NULL,'user.TotalHits >= 20000'),(66,'Catch 200,000 fruits','So, I heard you like fruit...',2,4,'fruits-hits-200000',NULL,'user.TotalHits >= 200000'),(67,'Catch 2,000,000 fruits','Downright healthy.',2,4,'fruits-hits-2000000',NULL,'user.TotalHits >= 2000000'),(68,'Catch 20,000,000 fruits','Nothing left behind.',2,4,'fruits-hits-20000000',NULL,'user.TotalHits >= 20000000'),(69,'First Steps','It isn''t 9-to-4, but 1-to-9. Keys, that is.',3,4,'mania-skill-pass-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2'),(70,'No Normal Player','Not anymore, at least.',3,4,'mania-skill-pass-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3'),(71,'Impulse Drive','Not quite hyperspeed, but getting close.',3,4,'mania-skill-pass-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4'),(72,'Hyperspeed','Woah.',3,4,'mania-skill-pass-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5'),(73,'Ever Onwards','Another challenge is just around the corner.',3,4,'mania-skill-pass-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6'),(74,'Another Surpassed','Is there no limit to your skills?',3,4,'mania-skill-pass-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7'),(75,'Extra Credit','See me after class.',3,4,'mania-skill-pass-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8'),(76,'Maniac','There''s just no stopping you.',3,4,'mania-skill-pass-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9'),(77,'Keystruck','The beginning of a new story.',3,4,'mania-skill-fc-1',NULL,'beatmap.DifficultyRating >= 1 && beatmap.DifficultyRating < 2 && score.Perfect'),(78,'Keying In','Finding your groove.',3,4,'mania-skill-fc-2',NULL,'beatmap.DifficultyRating >= 2 && beatmap.DifficultyRating < 3 && score.Perfect'),(79,'Hyperflow','You can *feel* the rhythm.',3,4,'mania-skill-fc-3',NULL,'beatmap.DifficultyRating >= 3 && beatmap.DifficultyRating < 4 && score.Perfect'),(80,'Breakthrough','Many skills mastered, rolled into one.',3,4,'mania-skill-fc-4',NULL,'beatmap.DifficultyRating >= 4 && beatmap.DifficultyRating < 5 && score.Perfect'),(81,'Everything Extra','Giving your all is giving everything you have.',3,4,'mania-skill-fc-5',NULL,'beatmap.DifficultyRating >= 5 && beatmap.DifficultyRating < 6 && score.Perfect'),(82,'Level Breaker','Finesse beyond reason.',3,4,'mania-skill-fc-6',NULL,'beatmap.DifficultyRating >= 6 && beatmap.DifficultyRating < 7 && score.Perfect'),(83,'Step Up','A precipice rarely seen.',3,4,'mania-skill-fc-7',NULL,'beatmap.DifficultyRating >= 7 && beatmap.DifficultyRating < 8 && score.Perfect'),(84,'Behind The Veil','Supernatural!',3,4,'mania-skill-fc-8',NULL,'beatmap.DifficultyRating >= 8 && beatmap.DifficultyRating < 9 && score.Perfect'),(85,'40,000 Keys','Just the start of the rainbow.',3,4,'mania-hits-40000',NULL,'user.TotalHits >= 40000'),(86,'400,000 Keys','Four hundred thousand and still not even close.',3,4,'mania-hits-400000',NULL,'user.TotalHits >= 400000'),(87,'4,000,000 Keys','Is this the end of the rainbow?',3,4,'mania-hits-4000000',NULL,'user.TotalHits >= 4000000'),(88,'40,000,000 Keys','The rainbow is eternal.',3,4,'mania-hits-40000000',NULL,'user.TotalHits >= 40000000'),(89,'Finality','High stakes, no regrets.',NULL,3,'all-intro-suddendeath',NULL,'(score.Mods & 32) == 32'),(90,'Perfectionist','Accept nothing but the best.',NULL,3,'all-intro-perfect',NULL,'(score.Mods & 16384) == 16384'),(91,'Rock Around The Clock','You can''t stop the rock.',NULL,3,'all-intro-hardrock',NULL,'(score.Mods & 16) == 16'),(92,'Time And A Half','Having a right ol'' time. One and a half of them, almost.',NULL,3,'all-intro-doubletime',NULL,'(score.Mods & 64) == 64'),(93,'Sweet Rave Party','Founded in the fine tradition of changing things that were just fine as they were.',NULL,3,'all-intro-nightcore',NULL,'(score.Mods & 512) == 512'),(94,'Blindsight','I can see just perfectly.',NULL,3,'all-intro-hidden',NULL,'(score.Mods & 8) == 8'),(95,'Are You Afraid Of The Dark?','Harder than it looks, probably because it''s hard to look.',NULL,3,'all-intro-flashlight',NULL,'(score.Mods & 1024) == 1024'),(96,'Dial It Right Back','Sometimes you just want to take it easy.',NULL,3,'all-intro-easy',NULL,'(score.Mods & 2) == 2'),(97,'Risk Averse','Safety nets are fun!',NULL,3,'all-intro-nofail',NULL,'(score.Mods & 1) == 1'),(98,'Slowboat','You got there. Eventually.',NULL,3,'all-intro-halftime',NULL,'(score.Mods & 256) == 256'),(99,'Burned Out','One cannot always spin to win.',NULL,3,'all-intro-spunout',NULL,'(score.Mods & 4096) == 4096'),(100,'Man this DJ is fire','Just don''t listen to the original. It''s not as good.',NULL,2,NULL,1,'beatmap.BeatmapsetId == 1357624'),(101,'Heat abnormal','Is it just me, or does my head get dizzy from all the heat?',NULL,2,NULL,2,'beatmap.BeatmapsetId == 2058976');
/*!40000 ALTER TABLE `medal` ENABLE KEYS */;

-- 
-- Definition of user
-- 

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Passhash` longtext NOT NULL,
  `Description` longtext,
  `Country` smallint NOT NULL,
  `Privilege` int NOT NULL,
  `RegisterDate` datetime(6) NOT NULL,
  `LastOnlineTime` datetime(6) NOT NULL,
  `AccountStatus` int NOT NULL,
  `SilencedUntil` datetime(6) NOT NULL,
  `DefaultGameMode` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_Email` (`Email`),
  UNIQUE KEY `IX_user_Username` (`Username`),
  KEY `IX_user_AccountStatus` (`AccountStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user
-- 

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user`(`Id`,`Username`,`Email`,`Passhash`,`Description`,`Country`,`Privilege`,`RegisterDate`,`LastOnlineTime`,`AccountStatus`,`SilencedUntil`,`DefaultGameMode`) VALUES(1001,'Tosume Bot','bot@mail.com','12345678','Let your smile be the sunshine that brightens the world around you.',12,32,'2025-08-01 10:02:45.365194','2025-08-02 02:00:07.814636',0,'0001-01-01 00:00:00.000000',0),(1002,'Yazid','dahlahg7@gmail.com','c848b5b86a1cde2e42aadc543472f5a4',NULL,100,0,'2025-08-01 16:29:58.578012','2025-08-01 16:29:58.578012',0,'0001-01-01 00:00:00.000000',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- 
-- Definition of beatmap_hype
-- 

DROP TABLE IF EXISTS `beatmap_hype`;
CREATE TABLE IF NOT EXISTS `beatmap_hype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `UserId` int NOT NULL,
  `Hypes` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_beatmap_hype_BeatmapSetId_UserId` (`BeatmapSetId`,`UserId`),
  KEY `IX_beatmap_hype_BeatmapSetId_Hypes` (`BeatmapSetId`,`Hypes`),
  KEY `IX_beatmap_hype_UserId` (`UserId`),
  CONSTRAINT `FK_beatmap_hype_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table beatmap_hype
-- 

/*!40000 ALTER TABLE `beatmap_hype` DISABLE KEYS */;

/*!40000 ALTER TABLE `beatmap_hype` ENABLE KEYS */;

-- 
-- Definition of custom_beatmap_status
-- 

DROP TABLE IF EXISTS `custom_beatmap_status`;
CREATE TABLE IF NOT EXISTS `custom_beatmap_status` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `BeatmapHash` varchar(255) NOT NULL,
  `UpdatedByUserId` int NOT NULL,
  `Status` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_custom_beatmap_status_UpdatedByUserId` (`UpdatedByUserId`),
  KEY `IX_custom_beatmap_status_BeatmapHash` (`BeatmapHash`),
  KEY `IX_custom_beatmap_status_BeatmapSetId` (`BeatmapSetId`),
  CONSTRAINT `FK_custom_beatmap_status_user_UpdatedByUserId` FOREIGN KEY (`UpdatedByUserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table custom_beatmap_status
-- 

/*!40000 ALTER TABLE `custom_beatmap_status` DISABLE KEYS */;

/*!40000 ALTER TABLE `custom_beatmap_status` ENABLE KEYS */;

-- 
-- Definition of event_beatmap
-- 

DROP TABLE IF EXISTS `event_beatmap`;
CREATE TABLE IF NOT EXISTS `event_beatmap` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `BeatmapSetId` int NOT NULL,
  `ExecutorId` int NOT NULL,
  `EventType` int NOT NULL,
  `JsonData` longtext,
  `Time` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_event_beatmap_BeatmapSetId` (`BeatmapSetId`),
  KEY `IX_event_beatmap_ExecutorId` (`ExecutorId`),
  CONSTRAINT `FK_event_beatmap_user_ExecutorId` FOREIGN KEY (`ExecutorId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table event_beatmap
-- 

/*!40000 ALTER TABLE `event_beatmap` DISABLE KEYS */;

/*!40000 ALTER TABLE `event_beatmap` ENABLE KEYS */;

-- 
-- Definition of event_user
-- 

DROP TABLE IF EXISTS `event_user`;
CREATE TABLE IF NOT EXISTS `event_user` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `EventType` int NOT NULL,
  `Ip` varchar(255) NOT NULL,
  `JsonData` longtext NOT NULL,
  `Time` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_event_user_EventType_UserId` (`EventType`,`UserId`),
  KEY `IX_event_user_UserId` (`UserId`),
  KEY `IX_event_user_EventType_Ip` (`EventType`,`Ip`),
  CONSTRAINT `FK_event_user_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table event_user
-- 

/*!40000 ALTER TABLE `event_user` DISABLE KEYS */;
INSERT INTO `event_user`(`Id`,`UserId`,`EventType`,`Ip`,`JsonData`,`Time`) VALUES(1,1002,2,'8.215.16.28','{\"RegisterData\":{\"Username\":\"Yazid\",\"Email\":\"dahlahg7@gmail.com\",\"Passhash\":\"c848b5b86a1cde2e42aadc543472f5a4\",\"Country\":100,\"RegisterDate\":\"2025-08-01T16:29:58.5780123Z\"}}','2025-08-01 16:29:58.770659'),(2,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T16:30:06.7527668Z\"}}','2025-08-01 16:30:06.753637'),(3,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T17:11:29.0569074Z\"}}','2025-08-01 17:11:29.056914'),(4,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-01T19:21:48.2448766Z\"}}','2025-08-01 19:21:48.244882'),(5,1002,1,'8.215.16.28','{\"LoginData\":{\"RequestHeader\":[\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 EdgA/138.0.0.0\"],\"RequestIp\":\"8.215.16.28\",\"RequestCountry\":\"ID\",\"RequestTime\":\"2025-08-02T01:38:59.7000056Z\"}}','2025-08-02 01:38:59.700013');
/*!40000 ALTER TABLE `event_user` ENABLE KEYS */;

-- 
-- Definition of restriction
-- 

DROP TABLE IF EXISTS `restriction`;
CREATE TABLE IF NOT EXISTS `restriction` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ExecutorId` int DEFAULT NULL,
  `Reason` longtext NOT NULL,
  `Date` datetime(6) NOT NULL,
  `ExpiryDate` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_restriction_ExecutorId` (`ExecutorId`),
  KEY `IX_restriction_UserId` (`UserId`),
  CONSTRAINT `FK_restriction_user_ExecutorId` FOREIGN KEY (`ExecutorId`) REFERENCES `user` (`Id`),
  CONSTRAINT `FK_restriction_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table restriction
-- 

/*!40000 ALTER TABLE `restriction` DISABLE KEYS */;

/*!40000 ALTER TABLE `restriction` ENABLE KEYS */;

-- 
-- Definition of score
-- 

DROP TABLE IF EXISTS `score`;
CREATE TABLE IF NOT EXISTS `score` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `BeatmapId` int NOT NULL,
  `ScoreHash` longtext NOT NULL,
  `BeatmapHash` varchar(255) NOT NULL,
  `ReplayFileId` int DEFAULT NULL,
  `TotalScore` bigint NOT NULL,
  `MaxCombo` int NOT NULL,
  `Count300` int NOT NULL,
  `Count100` int NOT NULL,
  `Count50` int NOT NULL,
  `CountMiss` int NOT NULL,
  `CountKatu` int NOT NULL,
  `CountGeki` int NOT NULL,
  `Perfect` tinyint(1) NOT NULL,
  `Mods` int NOT NULL,
  `Grade` longtext NOT NULL,
  `IsPassed` tinyint(1) NOT NULL,
  `IsScoreable` tinyint(1) NOT NULL,
  `SubmissionStatus` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `WhenPlayed` datetime(6) NOT NULL,
  `OsuVersion` longtext NOT NULL,
  `BeatmapStatus` int NOT NULL,
  `ClientTime` datetime(6) NOT NULL,
  `Accuracy` double NOT NULL,
  `PerformancePoints` double NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_score_ReplayFileId` (`ReplayFileId`),
  KEY `IX_score_UserId` (`UserId`),
  KEY `IX_score_BeatmapHash` (`BeatmapHash`),
  KEY `IX_score_BeatmapId_IsScoreable_IsPassed_SubmissionStatus` (`BeatmapId`,`IsScoreable`,`IsPassed`,`SubmissionStatus`),
  KEY `IX_score_GameMode_SubmissionStatus_BeatmapStatus_WhenPlayed` (`GameMode`,`SubmissionStatus`,`BeatmapStatus`,`WhenPlayed`),
  KEY `IX_score_UserId_BeatmapId` (`UserId`,`BeatmapId`),
  KEY `IX_score_UserId_SubmissionStatus_BeatmapStatus` (`UserId`,`SubmissionStatus`,`BeatmapStatus`),
  CONSTRAINT `FK_score_user_file_ReplayFileId` FOREIGN KEY (`ReplayFileId`) REFERENCES `user_file` (`Id`),
  CONSTRAINT `FK_score_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table score
-- 

/*!40000 ALTER TABLE `score` DISABLE KEYS */;

/*!40000 ALTER TABLE `score` ENABLE KEYS */;

-- 
-- Definition of user_favourite_beatmap
-- 

DROP TABLE IF EXISTS `user_favourite_beatmap`;
CREATE TABLE IF NOT EXISTS `user_favourite_beatmap` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `BeatmapSetId` int NOT NULL,
  `DateAdded` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_favourite_beatmap_UserId` (`UserId`),
  KEY `IX_user_favourite_beatmap_UserId_BeatmapSetId` (`UserId`,`BeatmapSetId`),
  CONSTRAINT `FK_user_favourite_beatmap_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_favourite_beatmap
-- 

/*!40000 ALTER TABLE `user_favourite_beatmap` DISABLE KEYS */;

/*!40000 ALTER TABLE `user_favourite_beatmap` ENABLE KEYS */;

-- 
-- Definition of user_file
-- 

DROP TABLE IF EXISTS `user_file`;
CREATE TABLE IF NOT EXISTS `user_file` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OwnerId` int NOT NULL,
  `Path` longtext NOT NULL,
  `Type` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_file_OwnerId` (`OwnerId`),
  KEY `IX_user_file_OwnerId_Type` (`OwnerId`,`Type`),
  CONSTRAINT `FK_user_file_user_OwnerId` FOREIGN KEY (`OwnerId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_file
-- 

/*!40000 ALTER TABLE `user_file` DISABLE KEYS */;
INSERT INTO `user_file`(`Id`,`OwnerId`,`Path`,`Type`,`CreatedAt`,`UpdatedAt`) VALUES(1,1001,'Files/Avatars/1.png',1,'2025-08-01 10:02:45.591213','2025-08-01 10:02:45.591213'),(2,1002,'Files/Banners/1002.jpg',2,'2025-08-01 17:05:47.437604','2025-08-01 17:05:47.437605'),(3,1002,'Files/Avatars/1002.jpg',1,'2025-08-01 17:08:46.244416','2025-08-01 17:08:46.244416');
/*!40000 ALTER TABLE `user_file` ENABLE KEYS */;

-- 
-- Definition of user_grades
-- 

DROP TABLE IF EXISTS `user_grades`;
CREATE TABLE IF NOT EXISTS `user_grades` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `CountXH` int NOT NULL,
  `CountX` int NOT NULL,
  `CountSH` int NOT NULL,
  `CountS` int NOT NULL,
  `CountA` int NOT NULL,
  `CountB` int NOT NULL,
  `CountC` int NOT NULL,
  `CountD` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_grades_UserId_GameMode` (`UserId`,`GameMode`),
  CONSTRAINT `FK_user_grades_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_grades
-- 

/*!40000 ALTER TABLE `user_grades` DISABLE KEYS */;
INSERT INTO `user_grades`(`Id`,`UserId`,`GameMode`,`CountXH`,`CountX`,`CountSH`,`CountS`,`CountA`,`CountB`,`CountC`,`CountD`) VALUES(1,1001,0,0,0,0,0,0,0,0,0),(2,1002,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `user_grades` ENABLE KEYS */;

-- 
-- Definition of user_inventory_item
-- 

DROP TABLE IF EXISTS `user_inventory_item`;
CREATE TABLE IF NOT EXISTS `user_inventory_item` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ItemType` int NOT NULL,
  `Quantity` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_inventory_item_UserId_ItemType` (`UserId`,`ItemType`),
  CONSTRAINT `FK_user_inventory_item_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_inventory_item
-- 

/*!40000 ALTER TABLE `user_inventory_item` DISABLE KEYS */;
INSERT INTO `user_inventory_item`(`Id`,`UserId`,`ItemType`,`Quantity`) VALUES(1,1002,0,10);
/*!40000 ALTER TABLE `user_inventory_item` ENABLE KEYS */;

-- 
-- Definition of user_medals
-- 

DROP TABLE IF EXISTS `user_medals`;
CREATE TABLE IF NOT EXISTS `user_medals` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `MedalId` int NOT NULL,
  `UnlockedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_medals_UserId` (`UserId`),
  CONSTRAINT `FK_user_medals_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_medals
-- 

/*!40000 ALTER TABLE `user_medals` DISABLE KEYS */;

/*!40000 ALTER TABLE `user_medals` ENABLE KEYS */;

-- 
-- Definition of user_metadata
-- 

DROP TABLE IF EXISTS `user_metadata`;
CREATE TABLE IF NOT EXISTS `user_metadata` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `Playstyle` int NOT NULL,
  `Location` varchar(32) NOT NULL,
  `Interest` varchar(32) NOT NULL,
  `Occupation` varchar(32) NOT NULL,
  `Telegram` varchar(32) NOT NULL,
  `Twitch` varchar(32) NOT NULL,
  `Twitter` varchar(32) NOT NULL,
  `Discord` varchar(32) NOT NULL,
  `Website` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_metadata_UserId` (`UserId`),
  CONSTRAINT `FK_user_metadata_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_metadata
-- 

/*!40000 ALTER TABLE `user_metadata` DISABLE KEYS */;
INSERT INTO `user_metadata`(`Id`,`UserId`,`Playstyle`,`Location`,`Interest`,`Occupation`,`Telegram`,`Twitch`,`Twitter`,`Discord`,`Website`) VALUES(1,1001,0,'','','','','','','',''),(2,1002,0,'','','','','','','','');
/*!40000 ALTER TABLE `user_metadata` ENABLE KEYS */;

-- 
-- Definition of user_relationship
-- 

DROP TABLE IF EXISTS `user_relationship`;
CREATE TABLE IF NOT EXISTS `user_relationship` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `TargetId` int NOT NULL,
  `Relation` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_relationship_TargetId` (`TargetId`),
  KEY `IX_user_relationship_UserId_TargetId` (`UserId`,`TargetId`),
  CONSTRAINT `FK_user_relationship_user_TargetId` FOREIGN KEY (`TargetId`) REFERENCES `user` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_user_relationship_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_relationship
-- 

/*!40000 ALTER TABLE `user_relationship` DISABLE KEYS */;

/*!40000 ALTER TABLE `user_relationship` ENABLE KEYS */;

-- 
-- Definition of user_stats
-- 

DROP TABLE IF EXISTS `user_stats`;
CREATE TABLE IF NOT EXISTS `user_stats` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `Accuracy` double NOT NULL,
  `TotalScore` bigint NOT NULL,
  `RankedScore` bigint NOT NULL,
  `PlayCount` int NOT NULL,
  `PerformancePoints` double NOT NULL,
  `MaxCombo` int NOT NULL,
  `PlayTime` int NOT NULL,
  `TotalHits` int NOT NULL,
  `BestGlobalRank` bigint DEFAULT NULL,
  `BestGlobalRankDate` datetime(6) DEFAULT NULL,
  `BestCountryRank` bigint DEFAULT NULL,
  `BestCountryRankDate` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_user_stats_UserId_GameMode` (`UserId`,`GameMode`),
  KEY `IX_user_stats_UserId` (`UserId`),
  CONSTRAINT `FK_user_stats_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_stats
-- 

/*!40000 ALTER TABLE `user_stats` DISABLE KEYS */;
INSERT INTO `user_stats`(`Id`,`UserId`,`GameMode`,`Accuracy`,`TotalScore`,`RankedScore`,`PlayCount`,`PerformancePoints`,`MaxCombo`,`PlayTime`,`TotalHits`,`BestGlobalRank`,`BestGlobalRankDate`,`BestCountryRank`,`BestCountryRankDate`) VALUES(1,1001,0,0,0,0,0,0,0,0,0,1,'2025-08-01 11:03:58.602154',1,'2025-08-01 11:03:58.602195'),(4,1002,0,0,0,0,0,0,0,0,0,2,'2025-08-01 16:29:58.668309',1,'2025-08-01 16:29:58.668351'),(5,1002,1,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.680813',1,'2025-08-01 16:29:58.680814'),(6,1002,2,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.686951',1,'2025-08-01 16:29:58.686952'),(7,1002,3,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.691687',1,'2025-08-01 16:29:58.691688'),(8,1002,4,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.698396',1,'2025-08-01 16:29:58.698397'),(9,1002,5,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.703255',1,'2025-08-01 16:29:58.703256'),(10,1002,6,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.708118',1,'2025-08-01 16:29:58.708119'),(11,1002,8,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.712848',1,'2025-08-01 16:29:58.712848'),(12,1002,12,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.717615',1,'2025-08-01 16:29:58.717616'),(13,1002,13,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.722200',1,'2025-08-01 16:29:58.722201'),(14,1002,14,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.726792',1,'2025-08-01 16:29:58.726793'),(15,1002,15,0,0,0,0,0,0,0,0,1,'2025-08-01 16:29:58.731247',1,'2025-08-01 16:29:58.731248');
/*!40000 ALTER TABLE `user_stats` ENABLE KEYS */;

-- 
-- Definition of user_stats_snapshot
-- 

DROP TABLE IF EXISTS `user_stats_snapshot`;
CREATE TABLE IF NOT EXISTS `user_stats_snapshot` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `GameMode` tinyint unsigned NOT NULL,
  `SnapshotsJson` longtext NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_user_stats_snapshot_UserId_GameMode` (`UserId`,`GameMode`),
  CONSTRAINT `FK_user_stats_snapshot_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `user` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table user_stats_snapshot
-- 

/*!40000 ALTER TABLE `user_stats_snapshot` DISABLE KEYS */;
INSERT INTO `user_stats_snapshot`(`Id`,`UserId`,`GameMode`,`SnapshotsJson`) VALUES(1,1001,0,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6491957Z\"}]'),(2,1002,0,'[{\"Rank\":2,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6611117Z\"}]'),(3,1002,1,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6787583Z\"}]'),(4,1002,2,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.6968545Z\"}]'),(5,1002,3,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7132513Z\"}]'),(6,1002,4,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7313849Z\"}]'),(7,1002,5,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7487522Z\"}]'),(8,1002,6,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7669478Z\"}]'),(9,1002,8,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.7859005Z\"}]'),(10,1002,12,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8046673Z\"}]'),(11,1002,13,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8235054Z\"}]'),(12,1002,14,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8421924Z\"}]'),(13,1002,15,'[{\"Rank\":1,\"CountryRank\":1,\"PerformancePoints\":0,\"SavedAt\":\"2025-08-01T23:59:13.8599926Z\"}]');
/*!40000 ALTER TABLE `user_stats_snapshot` ENABLE KEYS */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2025-08-02 03:00:10
-- Total time: 0:0:0:0:143 (d:h:m:s:ms)
